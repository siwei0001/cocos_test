"use strict";
cc._RF.push(module, 'e1b90/rohdEk4SdmmEZANaD', 'Helloworld');
// Script/Helloworld.ts

Object.defineProperty(exports, "__esModule", { value: true });
var ScrollViewProCom_1 = require("./ScrollViewProCom");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Helloworld = /** @class */ (function (_super) {
    __extends(Helloworld, _super);
    function Helloworld() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.scrollviewVertical = null;
        _this.scrollviewHorizontal = null;
        _this.scrollviewGrid = null;
        return _this;
    }
    Helloworld.prototype.start = function () {
        // init logic
        var datas = [];
        for (var i = 0; i < 1000; i++) {
            datas.push(i);
        }
        this.scrollviewVertical && this.scrollviewVertical.setView(datas, function (n, data, index) {
            var label = n.getComponentInChildren(cc.Label);
            label && (label.string = "NO." + data);
        });
        this.scrollviewHorizontal && this.scrollviewHorizontal.setView(datas, function (n, data, index) {
            var label = n.getComponentInChildren(cc.Label);
            label && (label.string = "NO." + data);
        });
        this.scrollviewGrid && this.scrollviewGrid.setView(datas, function (n, data, index) {
            var label = n.getComponentInChildren(cc.Label);
            label && (label.string = "NO." + data);
        });
    };
    __decorate([
        property({ type: ScrollViewProCom_1.default, displayName: "垂直布局列表" })
    ], Helloworld.prototype, "scrollviewVertical", void 0);
    __decorate([
        property({ type: ScrollViewProCom_1.default, displayName: "水平布局列表" })
    ], Helloworld.prototype, "scrollviewHorizontal", void 0);
    __decorate([
        property({ type: ScrollViewProCom_1.default, displayName: "网格布局列表" })
    ], Helloworld.prototype, "scrollviewGrid", void 0);
    Helloworld = __decorate([
        ccclass
    ], Helloworld);
    return Helloworld;
}(cc.Component));
exports.default = Helloworld;

cc._RF.pop();