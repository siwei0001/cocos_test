
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Helloworld.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e1b90/rohdEk4SdmmEZANaD', 'Helloworld');
// Script/Helloworld.ts

Object.defineProperty(exports, "__esModule", { value: true });
var ScrollViewProCom_1 = require("./ScrollViewProCom");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Helloworld = /** @class */ (function (_super) {
    __extends(Helloworld, _super);
    function Helloworld() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.scrollviewVertical = null;
        _this.scrollviewHorizontal = null;
        _this.scrollviewGrid = null;
        return _this;
    }
    Helloworld.prototype.start = function () {
        // init logic
        var datas = [];
        for (var i = 0; i < 1000; i++) {
            datas.push(i);
        }
        this.scrollviewVertical && this.scrollviewVertical.setView(datas, function (n, data, index) {
            var label = n.getComponentInChildren(cc.Label);
            label && (label.string = "NO." + data);
        });
        this.scrollviewHorizontal && this.scrollviewHorizontal.setView(datas, function (n, data, index) {
            var label = n.getComponentInChildren(cc.Label);
            label && (label.string = "NO." + data);
        });
        this.scrollviewGrid && this.scrollviewGrid.setView(datas, function (n, data, index) {
            var label = n.getComponentInChildren(cc.Label);
            label && (label.string = "NO." + data);
        });
    };
    __decorate([
        property({ type: ScrollViewProCom_1.default, displayName: "垂直布局列表" })
    ], Helloworld.prototype, "scrollviewVertical", void 0);
    __decorate([
        property({ type: ScrollViewProCom_1.default, displayName: "水平布局列表" })
    ], Helloworld.prototype, "scrollviewHorizontal", void 0);
    __decorate([
        property({ type: ScrollViewProCom_1.default, displayName: "网格布局列表" })
    ], Helloworld.prototype, "scrollviewGrid", void 0);
    Helloworld = __decorate([
        ccclass
    ], Helloworld);
    return Helloworld;
}(cc.Component));
exports.default = Helloworld;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TY3JpcHQvSGVsbG93b3JsZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsdURBQWtEO0FBRTVDLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDO0lBQXdDLDhCQUFZO0lBQXBEO1FBQUEscUVBOEJDO1FBM0JXLHdCQUFrQixHQUFxQixJQUFJLENBQUM7UUFFNUMsMEJBQW9CLEdBQXFCLElBQUksQ0FBQztRQUU5QyxvQkFBYyxHQUFxQixJQUFJLENBQUM7O0lBdUJwRCxDQUFDO0lBckJHLDBCQUFLLEdBQUw7UUFDSSxhQUFhO1FBQ2IsSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFDO1FBQ2YsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNuQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ2pCO1FBQ0QsSUFBSSxDQUFDLGtCQUFrQixJQUFJLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLFVBQUMsQ0FBVSxFQUFFLElBQVksRUFBRSxLQUFhO1lBQ3RHLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDL0MsS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxRQUFNLElBQU0sQ0FBQyxDQUFDO1FBQzNDLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLG9CQUFvQixJQUFJLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLFVBQUMsQ0FBVSxFQUFFLElBQVksRUFBRSxLQUFhO1lBQzFHLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDL0MsS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxRQUFNLElBQU0sQ0FBQyxDQUFDO1FBQzNDLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLGNBQWMsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsVUFBQyxDQUFVLEVBQUUsSUFBWSxFQUFFLEtBQWE7WUFDOUYsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUMvQyxLQUFLLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLFFBQU0sSUFBTSxDQUFDLENBQUM7UUFDM0MsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBMUJEO1FBREMsUUFBUSxDQUFDLEVBQUUsSUFBSSxFQUFFLDBCQUFnQixFQUFFLFdBQVcsRUFBRSxRQUFRLEVBQUUsQ0FBQzswREFDUjtJQUVwRDtRQURDLFFBQVEsQ0FBQyxFQUFFLElBQUksRUFBRSwwQkFBZ0IsRUFBRSxXQUFXLEVBQUUsUUFBUSxFQUFFLENBQUM7NERBQ047SUFFdEQ7UUFEQyxRQUFRLENBQUMsRUFBRSxJQUFJLEVBQUUsMEJBQWdCLEVBQUUsV0FBVyxFQUFFLFFBQVEsRUFBRSxDQUFDO3NEQUNaO0lBUC9CLFVBQVU7UUFEOUIsT0FBTztPQUNhLFVBQVUsQ0E4QjlCO0lBQUQsaUJBQUM7Q0E5QkQsQUE4QkMsQ0E5QnVDLEVBQUUsQ0FBQyxTQUFTLEdBOEJuRDtrQkE5Qm9CLFVBQVUiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgU2Nyb2xsVmlld1Byb0NvbSBmcm9tIFwiLi9TY3JvbGxWaWV3UHJvQ29tXCI7XHJcblxyXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgSGVsbG93b3JsZCBleHRlbmRzIGNjLkNvbXBvbmVudCB7XHJcblxyXG4gICAgQHByb3BlcnR5KHsgdHlwZTogU2Nyb2xsVmlld1Byb0NvbSwgZGlzcGxheU5hbWU6IFwi5Z6C55u05biD5bGA5YiX6KGoXCIgfSlcclxuICAgIHByaXZhdGUgc2Nyb2xsdmlld1ZlcnRpY2FsOiBTY3JvbGxWaWV3UHJvQ29tID0gbnVsbDtcclxuICAgIEBwcm9wZXJ0eSh7IHR5cGU6IFNjcm9sbFZpZXdQcm9Db20sIGRpc3BsYXlOYW1lOiBcIuawtOW5s+W4g+WxgOWIl+ihqFwiIH0pXHJcbiAgICBwcml2YXRlIHNjcm9sbHZpZXdIb3Jpem9udGFsOiBTY3JvbGxWaWV3UHJvQ29tID0gbnVsbDtcclxuICAgIEBwcm9wZXJ0eSh7IHR5cGU6IFNjcm9sbFZpZXdQcm9Db20sIGRpc3BsYXlOYW1lOiBcIue9keagvOW4g+WxgOWIl+ihqFwiIH0pXHJcbiAgICBwcml2YXRlIHNjcm9sbHZpZXdHcmlkOiBTY3JvbGxWaWV3UHJvQ29tID0gbnVsbDtcclxuXHJcbiAgICBzdGFydCgpIHtcclxuICAgICAgICAvLyBpbml0IGxvZ2ljXHJcbiAgICAgICAgbGV0IGRhdGFzID0gW107XHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IDEwMDA7IGkrKykge1xyXG4gICAgICAgICAgICBkYXRhcy5wdXNoKGkpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLnNjcm9sbHZpZXdWZXJ0aWNhbCAmJiB0aGlzLnNjcm9sbHZpZXdWZXJ0aWNhbC5zZXRWaWV3KGRhdGFzLCAobjogY2MuTm9kZSwgZGF0YTogbnVtYmVyLCBpbmRleDogbnVtYmVyKSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBsYWJlbCA9IG4uZ2V0Q29tcG9uZW50SW5DaGlsZHJlbihjYy5MYWJlbCk7XHJcbiAgICAgICAgICAgIGxhYmVsICYmIChsYWJlbC5zdHJpbmcgPSBgTk8uJHtkYXRhfWApO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGlzLnNjcm9sbHZpZXdIb3Jpem9udGFsICYmIHRoaXMuc2Nyb2xsdmlld0hvcml6b250YWwuc2V0VmlldyhkYXRhcywgKG46IGNjLk5vZGUsIGRhdGE6IG51bWJlciwgaW5kZXg6IG51bWJlcikgPT4ge1xyXG4gICAgICAgICAgICBsZXQgbGFiZWwgPSBuLmdldENvbXBvbmVudEluQ2hpbGRyZW4oY2MuTGFiZWwpO1xyXG4gICAgICAgICAgICBsYWJlbCAmJiAobGFiZWwuc3RyaW5nID0gYE5PLiR7ZGF0YX1gKTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5zY3JvbGx2aWV3R3JpZCAmJiB0aGlzLnNjcm9sbHZpZXdHcmlkLnNldFZpZXcoZGF0YXMsIChuOiBjYy5Ob2RlLCBkYXRhOiBudW1iZXIsIGluZGV4OiBudW1iZXIpID0+IHtcclxuICAgICAgICAgICAgbGV0IGxhYmVsID0gbi5nZXRDb21wb25lbnRJbkNoaWxkcmVuKGNjLkxhYmVsKTtcclxuICAgICAgICAgICAgbGFiZWwgJiYgKGxhYmVsLnN0cmluZyA9IGBOTy4ke2RhdGF9YCk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbn1cclxuIl19