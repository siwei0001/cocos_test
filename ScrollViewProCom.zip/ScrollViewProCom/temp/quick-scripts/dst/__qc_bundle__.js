
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/Script/Helloworld');
require('./assets/Script/ScrollViewProCom');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/ScrollViewProCom.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f8dc1baPvpMI766VmzbfCWr', 'ScrollViewProCom');
// Script/ScrollViewProCom.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property, menu = _a.menu;
var ScrollViewProCom = /** @class */ (function (_super) {
    __extends(ScrollViewProCom, _super);
    function ScrollViewProCom() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.type = 0;
        _this.itemNode = null;
        _this.itemPrefab = null;
        _this.curShowDatas = [];
        _this.allDatas = [];
        return _this;
    }
    ScrollViewProCom.prototype.onLoad = function () {
        this.comScrollView = this.node.getComponent(cc.ScrollView);
        if (null == this.comScrollView)
            return;
        this.content = this.comScrollView.content;
        if (null == this.content)
            return;
        this.layout = this.content.getComponent(cc.Layout);
        if (null == this.layout)
            return;
        this.layout.enabled = false;
        this.node.on("scrolling", this.onScrolling, this);
        this.node.on(cc.Node.EventType.SIZE_CHANGED, this.onSizeChanged, this);
        this.nodePool = [];
        for (var i = this.content.childrenCount - 1; i >= 0; i--) {
            this.nodePool.push(this.content.children[i]);
            this.content.children[i].setPosition(Number.MAX_VALUE, Number.MAX_VALUE);
        }
        this.updateContentSize();
        this.updateListView();
    };
    ScrollViewProCom.prototype.onDestroy = function () {
        this.node.off("scrolling", this.onScrolling, this);
        this.node.off(cc.Node.EventType.SIZE_CHANGED, this.onSizeChanged, this);
        clearInterval(this.interval);
    };
    /**
     * 设置视图
     * @param datas 用户数据
     * @param func 回调
     * @param key 根据key查询两次数据是否一样
     */
    ScrollViewProCom.prototype.setView = function (datas, func, key) {
        this.updateAllDatas(datas);
        this.func = func, this.key = key;
        this.updateContentSize();
        this.updateListView(true);
    };
    ScrollViewProCom.prototype.onSizeChanged = function () {
        this.updateListView();
    };
    ScrollViewProCom.prototype.onScrolling = function () {
        this.updateListView();
    };
    Object.defineProperty(ScrollViewProCom.prototype, "item", {
        get: function () {
            if (null == this._item) {
                if (0 == this.type && null != this.itemNode) {
                    this._item = cc.instantiate(this.itemNode);
                }
                else if (1 == this.type && null != this.itemPrefab) {
                    this._item = cc.instantiate(this.itemPrefab);
                }
            }
            return this._item;
        },
        enumerable: false,
        configurable: true
    });
    /**更新view */
    ScrollViewProCom.prototype.updateListView = function (executeAllCallback) {
        var _this = this;
        if (executeAllCallback === void 0) { executeAllCallback = false; }
        var datasNeedShow = this.getDatasNeedShow();
        //先把当前展示的item中不需要的移除
        for (var i = this.curShowDatas.length - 1; i >= 0; i--) {
            if (null == this.key) {
                for (var j = 0; j < datasNeedShow.length; j++) {
                    if (datasNeedShow[j][1] == this.curShowDatas[i].userData) {
                        break;
                    }
                }
            }
            else {
                for (var j = 0; j < datasNeedShow.length; j++) {
                    if (datasNeedShow[j][1][this.key] == this.curShowDatas[i].userData[this.key]) {
                        break;
                    }
                }
            }
            if (j >= datasNeedShow.length) { //不再需要了
                this.nodePool.push(this.curShowDatas[i].n);
                this.curShowDatas[i].n.setPosition(Number.MAX_VALUE, Number.MAX_VALUE);
                this.curShowDatas.splice(i, 1);
            }
        }
        var dataNeedInstantiate = [];
        var index = 0;
        //再添加需要显示的item和更新现有item的坐标
        for (var i = 0; i < datasNeedShow.length; i++) {
            if (null == this.key) {
                for (var j = 0; j < this.curShowDatas.length; j++) {
                    if (this.curShowDatas[j].userData == datasNeedShow[i][1]) {
                        break;
                    }
                }
            }
            else {
                for (var j = 0; j < this.curShowDatas.length; j++) {
                    if (this.curShowDatas[j].userData[this.key] == datasNeedShow[i][1][this.key]) {
                        break;
                    }
                }
            }
            if (j < this.curShowDatas.length) { //找到了，更新位置
                var curShowData = this.curShowDatas[j];
                if (curShowData.index != datasNeedShow[i][0]) { //位置不一样
                    curShowData.index = datasNeedShow[i][0];
                    var targetPos = this.getItemPosByIdx(curShowData.index);
                    cc.Tween.stopAllByTarget(curShowData.n);
                    cc.tween(curShowData.n)
                        .to(0.1, { position: targetPos })
                        .start();
                    true == executeAllCallback && true == cc.isValid(this.func) && this.func(curShowData.n, curShowData.userData, curShowData.index);
                }
            }
            else { //没找到，添加
                var newData = new ScrollViewProData(datasNeedShow[i][0], datasNeedShow[i][1]);
                newData.n = this.nodePool.pop();
                if (null == newData.n) {
                    dataNeedInstantiate.push([i, newData]);
                }
                else {
                    newData.n.setPosition(this.getItemPosByIdx(newData.index));
                    this.curShowDatas.splice(i, 0, newData); //添加位置是i
                    true == cc.isValid(this.func) && this.func(newData.n, newData.userData, newData.index);
                }
            }
        }
        //分帧添加
        clearInterval(this.interval);
        this.interval = setInterval(function () {
            if (index >= dataNeedInstantiate.length) {
                clearInterval(_this.interval);
                return;
            }
            var newData = dataNeedInstantiate[index][1];
            var pos = dataNeedInstantiate[index][0];
            newData.n = cc.instantiate(_this.item);
            _this.content.addChild(newData.n);
            newData.n.setPosition(_this.getItemPosByIdx(newData.index));
            _this.curShowDatas.splice(pos, 0, newData); //添加位置是i
            true == cc.isValid(_this.func) && _this.func(newData.n, newData.userData, newData.index);
            index++;
        });
    };
    /**更新总数据 */
    ScrollViewProCom.prototype.updateAllDatas = function (datas) {
        this.allDatas = [];
        for (var i = 0; i < datas.length; i++) {
            this.allDatas.push([i, datas[i]]);
        }
    };
    /**更新content尺寸 */
    ScrollViewProCom.prototype.updateContentSize = function () {
        if (null == this.content || null == this.layout)
            return;
        switch (this.layout.type) {
            case cc.Layout.Type.VERTICAL:
                this.content.height =
                    this.layout.paddingTop + this.layout.paddingBottom + this.allDatas.length * (this.layout.spacingY + this.item.height * this.item.scaleY) - this.layout.spacingY;
                break;
            case cc.Layout.Type.HORIZONTAL:
                this.content.width =
                    this.layout.paddingLeft + this.layout.paddingRight + this.allDatas.length * (this.layout.spacingX + this.item.width * this.item.scaleX) - this.layout.spacingX;
                break;
            case cc.Layout.Type.GRID:
                /**一行最多有多少个 */
                var cols = Math.floor((this.content.width - this.layout.paddingLeft - this.layout.paddingRight + this.layout.spacingX)
                    / (this.item.width * this.item.scaleX + this.layout.spacingX));
                /**一共多少行 */
                var rows = Math.ceil(this.allDatas.length / cols);
                this.content.height =
                    this.layout.paddingTop + this.layout.paddingBottom + rows * (this.layout.spacingY + this.item.height * this.item.scaleY) - this.layout.spacingY;
                break;
            default:
                break;
        }
    };
    /**获取需要展示的数据 */
    ScrollViewProCom.prototype.getDatasNeedShow = function () {
        if (null == this.content || null == this.layout)
            return [];
        switch (this.layout.type) {
            case cc.Layout.Type.VERTICAL:
                var contentHead = this.content.y + (1 - this.content.anchorY) * this.content.height - (1 - this.node.anchorY) * this.node.height;
                if (0 > contentHead)
                    contentHead = 0;
                var contendTail = this.node.height + this.content.y;
                if (contendTail < contentHead)
                    contendTail = contentHead;
                if (this.content.height - this.layout.paddingBottom < contendTail)
                    contendTail = this.content.height - this.layout.paddingBottom;
                var startIndex = Math.floor((contentHead - this.layout.paddingTop) / (this.item.height + this.layout.spacingY)); //多显示一个
                if (this.allDatas.length <= startIndex)
                    startIndex = this.allDatas.length - 1;
                if (0 > startIndex)
                    startIndex = 0;
                var endIndex = Math.ceil((contendTail - this.layout.paddingTop) / (this.item.height + this.layout.spacingY)); //多显示一个
                if (this.allDatas.length <= endIndex)
                    endIndex = this.allDatas.length - 1;
                if (endIndex < startIndex)
                    endIndex = startIndex;
                break;
            case cc.Layout.Type.HORIZONTAL:
                var contentHead = -(this.content.x - this.content.anchorX * this.content.width) + this.node.anchorX * this.node.width;
                if (0 > contentHead)
                    contentHead = 0;
                var contendTail = this.node.width - this.content.x;
                if (contendTail < contentHead)
                    contendTail = contentHead;
                if (this.content.width - this.layout.paddingRight < contendTail)
                    contendTail = this.content.width - this.layout.paddingRight;
                var startIndex = Math.floor((contentHead - this.layout.paddingLeft) / (this.item.width + this.layout.spacingX)); //多显示一个
                if (this.allDatas.length <= startIndex)
                    startIndex = this.allDatas.length - 1;
                if (0 > startIndex)
                    startIndex = 0;
                var endIndex = Math.ceil((contendTail - this.layout.paddingLeft) / (this.item.width + this.layout.spacingX)); //多显示一个
                if (this.allDatas.length <= endIndex)
                    endIndex = this.allDatas.length - 1;
                if (endIndex < startIndex)
                    endIndex = startIndex;
                break;
            case cc.Layout.Type.GRID:
                var contentHead = this.content.y + (1 - this.content.anchorY) * this.content.height - (1 - this.node.anchorY) * this.node.height;
                if (0 > contentHead)
                    contentHead = 0;
                var contendTail = this.node.height + this.content.y;
                if (contendTail < contentHead)
                    contendTail = contentHead;
                if (this.content.height - this.layout.paddingBottom < contendTail)
                    contendTail = this.content.height - this.layout.paddingBottom;
                /**一行最多有多少个 */
                var cols = Math.floor((this.content.width - this.layout.paddingLeft - this.layout.paddingRight + this.layout.spacingX)
                    / (this.item.width + this.layout.spacingX));
                var startIndex = Math.floor((contentHead - this.layout.paddingTop) / (this.item.height + this.layout.spacingY)) * cols;
                if (this.allDatas.length <= startIndex)
                    startIndex = this.allDatas.length - 1;
                if (0 > startIndex)
                    startIndex = 0;
                var endIndex = Math.ceil((contendTail - this.layout.paddingTop) / (this.item.height + this.layout.spacingY)) * cols - 1;
                if (this.allDatas.length <= endIndex)
                    endIndex = this.allDatas.length - 1;
                if (endIndex < startIndex)
                    endIndex = startIndex;
                break;
            default:
                break;
        }
        var ret = [];
        for (var i = startIndex; i < Math.min(this.allDatas.length, endIndex + 1); i++) {
            ret.push(this.allDatas[i]);
        }
        return ret;
    };
    /**根据节点下标获取节点应该所处的位置 */
    ScrollViewProCom.prototype.getItemPosByIdx = function (index) {
        if (null == this.content || null == this.layout)
            return cc.v3();
        switch (this.layout.type) {
            case cc.Layout.Type.VERTICAL:
                var deltaY = this.layout.paddingTop
                    + (1 - this.content.anchorY) * this.content.height
                    + (1 - this.item.anchorY) * this.item.height * this.item.scaleY
                    + index * (this.item.height * this.item.scaleY + this.layout.spacingY);
                return cc.v3(0, -deltaY, 0);
            case cc.Layout.Type.HORIZONTAL:
                var deltaX = this.layout.paddingLeft
                    - this.content.anchorX * this.content.width
                    + (this.item.anchorX) * this.item.width * this.item.scaleX
                    + index * (this.item.width * this.item.scaleX + this.layout.spacingX);
                return cc.v3(deltaX, 0, 0);
            case cc.Layout.Type.GRID:
                /**一行最多有多少个 */
                var cols = Math.floor((this.content.width - this.layout.paddingLeft - this.layout.paddingRight + this.layout.spacingX)
                    / (this.item.width * this.item.scaleX + this.layout.spacingX));
                var deltaY = this.layout.paddingTop
                    + (1 - this.content.anchorY) * this.content.height
                    + (1 - this.item.anchorY) * this.item.height * this.item.scaleY
                    + Math.floor(index / cols) * (this.item.height * this.item.scaleY + this.layout.spacingY);
                var deltaX = this.layout.paddingLeft
                    + (this.item.anchorX * this.item.width * this.item.scaleX) - this.content.anchorX * this.content.width
                    + (index % cols) * (this.item.width * this.item.scaleX + this.layout.spacingX);
                return cc.v3(deltaX, -deltaY, 0);
            default:
                return cc.v3();
        }
    };
    __decorate([
        property({ type: cc.Enum({ 节点: 0, 预制体: 1 }), displayName: "item类型" })
    ], ScrollViewProCom.prototype, "type", void 0);
    __decorate([
        property({
            type: cc.Node,
            visible: function () {
                return this.type == 0;
            },
            displayName: "item节点"
        })
    ], ScrollViewProCom.prototype, "itemNode", void 0);
    __decorate([
        property({
            type: cc.Prefab,
            visible: function () {
                return this.type == 1;
            },
            displayName: "item预制体"
        })
    ], ScrollViewProCom.prototype, "itemPrefab", void 0);
    ScrollViewProCom = __decorate([
        ccclass,
        menu("用户脚本组件/滚动视图优化组件")
    ], ScrollViewProCom);
    return ScrollViewProCom;
}(cc.Component));
exports.default = ScrollViewProCom;
var ScrollViewProData = /** @class */ (function () {
    function ScrollViewProData(index, userData) {
        this.index = index;
        this.userData = userData;
    }
    return ScrollViewProData;
}());

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TY3JpcHQvU2Nyb2xsVmlld1Byb0NvbS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQU0sSUFBQSxLQUE4QixFQUFFLENBQUMsVUFBVSxFQUF6QyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQUEsRUFBRSxJQUFJLFVBQWtCLENBQUM7QUFJbEQ7SUFBOEMsb0NBQVk7SUFBMUQ7UUFBQSxxRUE2VEM7UUEzVFcsVUFBSSxHQUFXLENBQUMsQ0FBQztRQU1qQixjQUFRLEdBQVksSUFBSSxDQUFDO1FBTXpCLGdCQUFVLEdBQWMsSUFBSSxDQUFDO1FBUzdCLGtCQUFZLEdBQTZCLEVBQUUsQ0FBQztRQUU1QyxjQUFRLEdBQXlCLEVBQUUsQ0FBQzs7SUFvU2hELENBQUM7SUFqU2EsaUNBQU0sR0FBaEI7UUFDSSxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUMzRCxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsYUFBYTtZQUFFLE9BQU87UUFDdkMsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQztRQUMxQyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsT0FBTztZQUFFLE9BQU87UUFDakMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDbkQsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLE1BQU07WUFBRSxPQUFPO1FBQ2hDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztRQUU1QixJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNsRCxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUN2RSxJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztRQUNuQixLQUFLLElBQUksQ0FBQyxHQUFXLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzlELElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDN0MsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1NBQzVFO1FBQ0QsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDekIsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO0lBQzFCLENBQUM7SUFFUyxvQ0FBUyxHQUFuQjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ25ELElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3hFLGFBQWEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDakMsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksa0NBQU8sR0FBZCxVQUFlLEtBQWlCLEVBQUUsSUFBb0QsRUFBRSxHQUFZO1FBQ2hHLElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDM0IsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLEVBQUUsSUFBSSxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUM7UUFDakMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDekIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUM5QixDQUFDO0lBRU8sd0NBQWEsR0FBckI7UUFDSSxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7SUFDMUIsQ0FBQztJQUVPLHNDQUFXLEdBQW5CO1FBQ0ksSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO0lBQzFCLENBQUM7SUFFRCxzQkFBWSxrQ0FBSTthQUFoQjtZQUNJLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxLQUFLLEVBQUU7Z0JBQ3BCLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUU7b0JBQ3pDLElBQUksQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7aUJBQzlDO3FCQUFNLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUU7b0JBQ2xELElBQUksQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7aUJBQ2hEO2FBQ0o7WUFFRCxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDdEIsQ0FBQzs7O09BQUE7SUFFRCxZQUFZO0lBQ0oseUNBQWMsR0FBdEIsVUFBdUIsa0JBQW1DO1FBQTFELGlCQXNGQztRQXRGc0IsbUNBQUEsRUFBQSwwQkFBbUM7UUFDdEQsSUFBSSxhQUFhLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDNUMsb0JBQW9CO1FBQ3BCLEtBQUssSUFBSSxDQUFDLEdBQVcsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDNUQsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDbEIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGFBQWEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQzNDLElBQUksYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFO3dCQUN0RCxNQUFNO3FCQUNUO2lCQUNKO2FBQ0o7aUJBQU07Z0JBQ0gsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGFBQWEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQzNDLElBQUksYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUU7d0JBQzFFLE1BQU07cUJBQ1Q7aUJBQ0o7YUFDSjtZQUVELElBQUksQ0FBQyxJQUFJLGFBQWEsQ0FBQyxNQUFNLEVBQUUsRUFBQyxPQUFPO2dCQUNuQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUMzQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBQ3ZFLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQzthQUNsQztTQUNKO1FBRUQsSUFBSSxtQkFBbUIsR0FBc0IsRUFBRSxDQUFDO1FBQ2hELElBQUksS0FBSyxHQUFXLENBQUMsQ0FBQztRQUN0QiwwQkFBMEI7UUFDMUIsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGFBQWEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDbkQsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDbEIsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO29CQUN2RCxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxJQUFJLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDdEQsTUFBTTtxQkFDVDtpQkFDSjthQUNKO2lCQUFNO2dCQUNILEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtvQkFDdkQsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRTt3QkFDMUUsTUFBTTtxQkFDVDtpQkFDSjthQUNKO1lBRUQsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsRUFBQyxVQUFVO2dCQUN6QyxJQUFJLFdBQVcsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN2QyxJQUFJLFdBQVcsQ0FBQyxLQUFLLElBQUksYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUMsT0FBTztvQkFDbEQsV0FBVyxDQUFDLEtBQUssR0FBRyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ3hDLElBQUksU0FBUyxHQUFZLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUNqRSxFQUFFLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ3hDLEVBQUUsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQzt5QkFDbEIsRUFBRSxDQUFDLEdBQUcsRUFBRSxFQUFFLFFBQVEsRUFBRSxTQUFTLEVBQUUsQ0FBQzt5QkFDaEMsS0FBSyxFQUFFLENBQUM7b0JBQ2IsSUFBSSxJQUFJLGtCQUFrQixJQUFJLElBQUksSUFBSSxFQUFFLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUUsV0FBVyxDQUFDLFFBQVEsRUFBRSxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7aUJBQ3BJO2FBQ0o7aUJBQU0sRUFBQyxRQUFRO2dCQUNaLElBQUksT0FBTyxHQUFHLElBQUksaUJBQWlCLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUM5RSxPQUFPLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxFQUFFLENBQUM7Z0JBQ2hDLElBQUksSUFBSSxJQUFJLE9BQU8sQ0FBQyxDQUFDLEVBQUU7b0JBQ25CLG1CQUFtQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDO2lCQUMxQztxQkFBTTtvQkFDSCxPQUFPLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO29CQUMzRCxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUEsUUFBUTtvQkFDaEQsSUFBSSxJQUFJLEVBQUUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztpQkFDMUY7YUFDSjtTQUNKO1FBRUQsTUFBTTtRQUNOLGFBQWEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDN0IsSUFBSSxDQUFDLFFBQVEsR0FBRyxXQUFXLENBQUM7WUFDeEIsSUFBSSxLQUFLLElBQUksbUJBQW1CLENBQUMsTUFBTSxFQUFFO2dCQUNyQyxhQUFhLENBQUMsS0FBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUM3QixPQUFPO2FBQ1Y7WUFFRCxJQUFJLE9BQU8sR0FBRyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM1QyxJQUFJLEdBQUcsR0FBRyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN4QyxPQUFPLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsS0FBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ3RDLEtBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVqQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxLQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1lBQzNELEtBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQSxRQUFRO1lBQ2xELElBQUksSUFBSSxFQUFFLENBQUMsT0FBTyxDQUFDLEtBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7WUFFdkYsS0FBSyxFQUFFLENBQUM7UUFDWixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCxXQUFXO0lBQ0gseUNBQWMsR0FBdEIsVUFBdUIsS0FBaUI7UUFDcEMsSUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7UUFDbkIsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDM0MsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUNyQztJQUNMLENBQUM7SUFFRCxpQkFBaUI7SUFDVCw0Q0FBaUIsR0FBekI7UUFDSSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsT0FBTyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsTUFBTTtZQUFFLE9BQU87UUFDeEQsUUFBUSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRTtZQUN0QixLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVE7Z0JBQ3hCLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTTtvQkFDZixJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7Z0JBQ3BLLE1BQU07WUFDVixLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVU7Z0JBQzFCLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSztvQkFDZCxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7Z0JBQ25LLE1BQU07WUFDVixLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUk7Z0JBQ3BCLGNBQWM7Z0JBQ2QsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO3NCQUNoSCxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztnQkFDbkUsV0FBVztnQkFDWCxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxDQUFDO2dCQUNsRCxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU07b0JBQ2YsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLEdBQUcsSUFBSSxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztnQkFDcEosTUFBTTtZQUNWO2dCQUNJLE1BQU07U0FDYjtJQUNMLENBQUM7SUFFRCxlQUFlO0lBQ1AsMkNBQWdCLEdBQXhCO1FBQ0ksSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLE9BQU8sSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLE1BQU07WUFBRSxPQUFPLEVBQUUsQ0FBQztRQUMzRCxRQUFRLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFO1lBQ3RCLEtBQUssRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUTtnQkFDeEIsSUFBSSxXQUFXLEdBQVcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO2dCQUN6SSxJQUFJLENBQUMsR0FBRyxXQUFXO29CQUFFLFdBQVcsR0FBRyxDQUFDLENBQUM7Z0JBQ3JDLElBQUksV0FBVyxHQUFXLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO2dCQUM1RCxJQUFJLFdBQVcsR0FBRyxXQUFXO29CQUFFLFdBQVcsR0FBRyxXQUFXLENBQUM7Z0JBQ3pELElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLEdBQUcsV0FBVztvQkFBRSxXQUFXLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUM7Z0JBRWpJLElBQUksVUFBVSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQ3ZCLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUNyRixDQUFDLENBQUEsT0FBTztnQkFDVCxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxJQUFJLFVBQVU7b0JBQUUsVUFBVSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztnQkFDOUUsSUFBSSxDQUFDLEdBQUcsVUFBVTtvQkFBRSxVQUFVLEdBQUcsQ0FBQyxDQUFDO2dCQUVuQyxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUNwQixDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FDckYsQ0FBQyxDQUFBLE9BQU87Z0JBQ1QsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sSUFBSSxRQUFRO29CQUFFLFFBQVEsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7Z0JBQzFFLElBQUksUUFBUSxHQUFHLFVBQVU7b0JBQUUsUUFBUSxHQUFHLFVBQVUsQ0FBQztnQkFDakQsTUFBTTtZQUNWLEtBQUssRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVTtnQkFDMUIsSUFBSSxXQUFXLEdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7Z0JBQzlILElBQUksQ0FBQyxHQUFHLFdBQVc7b0JBQUUsV0FBVyxHQUFHLENBQUMsQ0FBQztnQkFDckMsSUFBSSxXQUFXLEdBQVcsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7Z0JBQzNELElBQUksV0FBVyxHQUFHLFdBQVc7b0JBQUUsV0FBVyxHQUFHLFdBQVcsQ0FBQztnQkFDekQsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksR0FBRyxXQUFXO29CQUFFLFdBQVcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQztnQkFFN0gsSUFBSSxVQUFVLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FDdkIsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQ3JGLENBQUMsQ0FBQSxPQUFPO2dCQUNULElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLElBQUksVUFBVTtvQkFBRSxVQUFVLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO2dCQUM5RSxJQUFJLENBQUMsR0FBRyxVQUFVO29CQUFFLFVBQVUsR0FBRyxDQUFDLENBQUM7Z0JBRW5DLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQ3BCLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUNyRixDQUFDLENBQUEsT0FBTztnQkFDVCxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxJQUFJLFFBQVE7b0JBQUUsUUFBUSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztnQkFDMUUsSUFBSSxRQUFRLEdBQUcsVUFBVTtvQkFBRSxRQUFRLEdBQUcsVUFBVSxDQUFDO2dCQUNqRCxNQUFNO1lBQ1YsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJO2dCQUNwQixJQUFJLFdBQVcsR0FBVyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7Z0JBQ3pJLElBQUksQ0FBQyxHQUFHLFdBQVc7b0JBQUUsV0FBVyxHQUFHLENBQUMsQ0FBQztnQkFDckMsSUFBSSxXQUFXLEdBQVcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7Z0JBQzVELElBQUksV0FBVyxHQUFHLFdBQVc7b0JBQUUsV0FBVyxHQUFHLFdBQVcsQ0FBQztnQkFDekQsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsR0FBRyxXQUFXO29CQUFFLFdBQVcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQztnQkFFakksY0FBYztnQkFDZCxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7c0JBQ2hILENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO2dCQUNoRCxJQUFJLFVBQVUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUN2QixDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FDckYsR0FBRyxJQUFJLENBQUM7Z0JBQ1QsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sSUFBSSxVQUFVO29CQUFFLFVBQVUsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7Z0JBQzlFLElBQUksQ0FBQyxHQUFHLFVBQVU7b0JBQUUsVUFBVSxHQUFHLENBQUMsQ0FBQztnQkFFbkMsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FDcEIsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQ3JGLEdBQUcsSUFBSSxHQUFHLENBQUMsQ0FBQztnQkFDYixJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxJQUFJLFFBQVE7b0JBQUUsUUFBUSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztnQkFDMUUsSUFBSSxRQUFRLEdBQUcsVUFBVTtvQkFBRSxRQUFRLEdBQUcsVUFBVSxDQUFDO2dCQUNqRCxNQUFNO1lBQ1Y7Z0JBQ0ksTUFBTTtTQUNiO1FBRUQsSUFBSSxHQUFHLEdBQXlCLEVBQUUsQ0FBQztRQUNuQyxLQUFLLElBQUksQ0FBQyxHQUFXLFVBQVUsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxRQUFRLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDcEYsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDOUI7UUFDRCxPQUFPLEdBQUcsQ0FBQztJQUNmLENBQUM7SUFFRCx1QkFBdUI7SUFDZiwwQ0FBZSxHQUF2QixVQUF3QixLQUFhO1FBQ2pDLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxPQUFPLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxNQUFNO1lBQUUsT0FBTyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7UUFDaEUsUUFBUSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRTtZQUN0QixLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVE7Z0JBQ3hCLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVTtzQkFDN0IsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU07c0JBQ2hELENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNO3NCQUM3RCxLQUFLLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUMzRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQ2hDLEtBQUssRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVTtnQkFDMUIsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXO3NCQUM5QixJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUs7c0JBQ3pDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU07c0JBQ3hELEtBQUssR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQzFFLE9BQU8sRUFBRSxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQy9CLEtBQUssRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSTtnQkFDcEIsY0FBYztnQkFDZCxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7c0JBQ2hILENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO2dCQUNuRSxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVU7c0JBQzdCLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNO3NCQUNoRCxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTTtzQkFDN0QsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUM5RixJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVc7c0JBQzlCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUs7c0JBQ3BHLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQTtnQkFDbEYsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQztZQUNyQztnQkFDSSxPQUFPLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztTQUN0QjtJQUNMLENBQUM7SUExVEQ7UUFEQyxRQUFRLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLEVBQUUsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsV0FBVyxFQUFFLFFBQVEsRUFBRSxDQUFDO2tEQUM3QztJQU16QjtRQUxDLFFBQVEsQ0FBQztZQUNOLElBQUksRUFBRSxFQUFFLENBQUMsSUFBSTtZQUFFLE9BQU87Z0JBQ2xCLE9BQU8sSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLENBQUM7WUFDMUIsQ0FBQztZQUFFLFdBQVcsRUFBRSxRQUFRO1NBQzNCLENBQUM7c0RBQytCO0lBTWpDO1FBTEMsUUFBUSxDQUFDO1lBQ04sSUFBSSxFQUFFLEVBQUUsQ0FBQyxNQUFNO1lBQUUsT0FBTztnQkFDcEIsT0FBTyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQztZQUMxQixDQUFDO1lBQUUsV0FBVyxFQUFFLFNBQVM7U0FDNUIsQ0FBQzt3REFDbUM7SUFkcEIsZ0JBQWdCO1FBRnBDLE9BQU87UUFDUCxJQUFJLENBQUMsaUJBQWlCLENBQUM7T0FDSCxnQkFBZ0IsQ0E2VHBDO0lBQUQsdUJBQUM7Q0E3VEQsQUE2VEMsQ0E3VDZDLEVBQUUsQ0FBQyxTQUFTLEdBNlR6RDtrQkE3VG9CLGdCQUFnQjtBQStUckM7SUFPSSwyQkFBWSxLQUFhLEVBQUUsUUFBYTtRQUNwQyxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztRQUNuQixJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztJQUM3QixDQUFDO0lBQ0wsd0JBQUM7QUFBRCxDQVhBLEFBV0MsSUFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHksIG1lbnUgfSA9IGNjLl9kZWNvcmF0b3I7XHJcblxyXG5AY2NjbGFzc1xyXG5AbWVudShcIueUqOaIt+iEmuacrOe7hOS7ti/mu5rliqjop4blm77kvJjljJbnu4Tku7ZcIilcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgU2Nyb2xsVmlld1Byb0NvbSBleHRlbmRzIGNjLkNvbXBvbmVudCB7XHJcbiAgICBAcHJvcGVydHkoeyB0eXBlOiBjYy5FbnVtKHsg6IqC54K5OiAwLCDpooTliLbkvZM6IDEgfSksIGRpc3BsYXlOYW1lOiBcIml0ZW3nsbvlnotcIiB9KVxyXG4gICAgcHJpdmF0ZSB0eXBlOiBudW1iZXIgPSAwO1xyXG4gICAgQHByb3BlcnR5KHtcclxuICAgICAgICB0eXBlOiBjYy5Ob2RlLCB2aXNpYmxlKCkge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy50eXBlID09IDA7XHJcbiAgICAgICAgfSwgZGlzcGxheU5hbWU6IFwiaXRlbeiKgueCuVwiXHJcbiAgICB9KVxyXG4gICAgcHJpdmF0ZSBpdGVtTm9kZTogY2MuTm9kZSA9IG51bGw7XHJcbiAgICBAcHJvcGVydHkoe1xyXG4gICAgICAgIHR5cGU6IGNjLlByZWZhYiwgdmlzaWJsZSgpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMudHlwZSA9PSAxO1xyXG4gICAgICAgIH0sIGRpc3BsYXlOYW1lOiBcIml0ZW3pooTliLbkvZNcIlxyXG4gICAgfSlcclxuICAgIHByaXZhdGUgaXRlbVByZWZhYjogY2MuUHJlZmFiID0gbnVsbDtcclxuXHJcbiAgICBwcml2YXRlIGNvbVNjcm9sbFZpZXc6IGNjLlNjcm9sbFZpZXc7XHJcbiAgICBwcml2YXRlIGNvbnRlbnQ6IGNjLk5vZGU7XHJcbiAgICBwcml2YXRlIGxheW91dDogY2MuTGF5b3V0O1xyXG4gICAgcHJpdmF0ZSBfaXRlbTogY2MuTm9kZTtcclxuICAgIHByaXZhdGUgbm9kZVBvb2w6IEFycmF5PGNjLk5vZGU+O1xyXG4gICAgcHJpdmF0ZSBpbnRlcnZhbDogbnVtYmVyO1xyXG5cclxuICAgIHByaXZhdGUgY3VyU2hvd0RhdGFzOiBBcnJheTxTY3JvbGxWaWV3UHJvRGF0YT4gPSBbXTtcclxuXHJcbiAgICBwcml2YXRlIGFsbERhdGFzOiBBcnJheTxbbnVtYmVyLCBhbnldPiA9IFtdO1xyXG4gICAgcHJpdmF0ZSBmdW5jOiBGdW5jdGlvbjtcclxuICAgIHByaXZhdGUga2V5OiBzdHJpbmc7XHJcbiAgICBwcm90ZWN0ZWQgb25Mb2FkKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuY29tU2Nyb2xsVmlldyA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuU2Nyb2xsVmlldyk7XHJcbiAgICAgICAgaWYgKG51bGwgPT0gdGhpcy5jb21TY3JvbGxWaWV3KSByZXR1cm47XHJcbiAgICAgICAgdGhpcy5jb250ZW50ID0gdGhpcy5jb21TY3JvbGxWaWV3LmNvbnRlbnQ7XHJcbiAgICAgICAgaWYgKG51bGwgPT0gdGhpcy5jb250ZW50KSByZXR1cm47XHJcbiAgICAgICAgdGhpcy5sYXlvdXQgPSB0aGlzLmNvbnRlbnQuZ2V0Q29tcG9uZW50KGNjLkxheW91dCk7XHJcbiAgICAgICAgaWYgKG51bGwgPT0gdGhpcy5sYXlvdXQpIHJldHVybjtcclxuICAgICAgICB0aGlzLmxheW91dC5lbmFibGVkID0gZmFsc2U7XHJcblxyXG4gICAgICAgIHRoaXMubm9kZS5vbihcInNjcm9sbGluZ1wiLCB0aGlzLm9uU2Nyb2xsaW5nLCB0aGlzKTtcclxuICAgICAgICB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuU0laRV9DSEFOR0VELCB0aGlzLm9uU2l6ZUNoYW5nZWQsIHRoaXMpO1xyXG4gICAgICAgIHRoaXMubm9kZVBvb2wgPSBbXTtcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSB0aGlzLmNvbnRlbnQuY2hpbGRyZW5Db3VudCAtIDE7IGkgPj0gMDsgaS0tKSB7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZVBvb2wucHVzaCh0aGlzLmNvbnRlbnQuY2hpbGRyZW5baV0pO1xyXG4gICAgICAgICAgICB0aGlzLmNvbnRlbnQuY2hpbGRyZW5baV0uc2V0UG9zaXRpb24oTnVtYmVyLk1BWF9WQUxVRSwgTnVtYmVyLk1BWF9WQUxVRSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMudXBkYXRlQ29udGVudFNpemUoKTtcclxuICAgICAgICB0aGlzLnVwZGF0ZUxpc3RWaWV3KCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIG9uRGVzdHJveSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLm5vZGUub2ZmKFwic2Nyb2xsaW5nXCIsIHRoaXMub25TY3JvbGxpbmcsIHRoaXMpO1xyXG4gICAgICAgIHRoaXMubm9kZS5vZmYoY2MuTm9kZS5FdmVudFR5cGUuU0laRV9DSEFOR0VELCB0aGlzLm9uU2l6ZUNoYW5nZWQsIHRoaXMpO1xyXG4gICAgICAgIGNsZWFySW50ZXJ2YWwodGhpcy5pbnRlcnZhbCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDorr7nva7op4blm75cclxuICAgICAqIEBwYXJhbSBkYXRhcyDnlKjmiLfmlbDmja5cclxuICAgICAqIEBwYXJhbSBmdW5jIOWbnuiwg1xyXG4gICAgICogQHBhcmFtIGtleSDmoLnmja5rZXnmn6Xor6LkuKTmrKHmlbDmja7mmK/lkKbkuIDmoLdcclxuICAgICAqL1xyXG4gICAgcHVibGljIHNldFZpZXcoZGF0YXM6IEFycmF5PGFueT4sIGZ1bmM6IChuOiBjYy5Ob2RlLCBkYXRhOiBhbnksIGluZGV4OiBudW1iZXIpID0+IHZvaWQsIGtleT86IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMudXBkYXRlQWxsRGF0YXMoZGF0YXMpO1xyXG4gICAgICAgIHRoaXMuZnVuYyA9IGZ1bmMsIHRoaXMua2V5ID0ga2V5O1xyXG4gICAgICAgIHRoaXMudXBkYXRlQ29udGVudFNpemUoKTtcclxuICAgICAgICB0aGlzLnVwZGF0ZUxpc3RWaWV3KHRydWUpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgb25TaXplQ2hhbmdlZCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLnVwZGF0ZUxpc3RWaWV3KCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBvblNjcm9sbGluZygpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLnVwZGF0ZUxpc3RWaWV3KCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBnZXQgaXRlbSgpOiBjYy5Ob2RlIHtcclxuICAgICAgICBpZiAobnVsbCA9PSB0aGlzLl9pdGVtKSB7XHJcbiAgICAgICAgICAgIGlmICgwID09IHRoaXMudHlwZSAmJiBudWxsICE9IHRoaXMuaXRlbU5vZGUpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2l0ZW0gPSBjYy5pbnN0YW50aWF0ZSh0aGlzLml0ZW1Ob2RlKTtcclxuICAgICAgICAgICAgfSBlbHNlIGlmICgxID09IHRoaXMudHlwZSAmJiBudWxsICE9IHRoaXMuaXRlbVByZWZhYikge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5faXRlbSA9IGNjLmluc3RhbnRpYXRlKHRoaXMuaXRlbVByZWZhYik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB0aGlzLl9pdGVtO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKuabtOaWsHZpZXcgKi9cclxuICAgIHByaXZhdGUgdXBkYXRlTGlzdFZpZXcoZXhlY3V0ZUFsbENhbGxiYWNrOiBib29sZWFuID0gZmFsc2UpOiB2b2lkIHtcclxuICAgICAgICBsZXQgZGF0YXNOZWVkU2hvdyA9IHRoaXMuZ2V0RGF0YXNOZWVkU2hvdygpO1xyXG4gICAgICAgIC8v5YWI5oqK5b2T5YmN5bGV56S655qEaXRlbeS4reS4jemcgOimgeeahOenu+mZpFxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IHRoaXMuY3VyU2hvd0RhdGFzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XHJcbiAgICAgICAgICAgIGlmIChudWxsID09IHRoaXMua2V5KSB7XHJcbiAgICAgICAgICAgICAgICBmb3IgKHZhciBqID0gMDsgaiA8IGRhdGFzTmVlZFNob3cubGVuZ3RoOyBqKyspIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoZGF0YXNOZWVkU2hvd1tqXVsxXSA9PSB0aGlzLmN1clNob3dEYXRhc1tpXS51c2VyRGF0YSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBmb3IgKHZhciBqID0gMDsgaiA8IGRhdGFzTmVlZFNob3cubGVuZ3RoOyBqKyspIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoZGF0YXNOZWVkU2hvd1tqXVsxXVt0aGlzLmtleV0gPT0gdGhpcy5jdXJTaG93RGF0YXNbaV0udXNlckRhdGFbdGhpcy5rZXldKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKGogPj0gZGF0YXNOZWVkU2hvdy5sZW5ndGgpIHsvL+S4jeWGjemcgOimgeS6hlxyXG4gICAgICAgICAgICAgICAgdGhpcy5ub2RlUG9vbC5wdXNoKHRoaXMuY3VyU2hvd0RhdGFzW2ldLm4pO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jdXJTaG93RGF0YXNbaV0ubi5zZXRQb3NpdGlvbihOdW1iZXIuTUFYX1ZBTFVFLCBOdW1iZXIuTUFYX1ZBTFVFKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuY3VyU2hvd0RhdGFzLnNwbGljZShpLCAxKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IGRhdGFOZWVkSW5zdGFudGlhdGU6IEFycmF5PEFycmF5PGFueT4+ID0gW107XHJcbiAgICAgICAgbGV0IGluZGV4OiBudW1iZXIgPSAwO1xyXG4gICAgICAgIC8v5YaN5re75Yqg6ZyA6KaB5pi+56S655qEaXRlbeWSjOabtOaWsOeOsOaciWl0ZW3nmoTlnZDmoIdcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgZGF0YXNOZWVkU2hvdy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBpZiAobnVsbCA9PSB0aGlzLmtleSkge1xyXG4gICAgICAgICAgICAgICAgZm9yICh2YXIgajogbnVtYmVyID0gMDsgaiA8IHRoaXMuY3VyU2hvd0RhdGFzLmxlbmd0aDsgaisrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuY3VyU2hvd0RhdGFzW2pdLnVzZXJEYXRhID09IGRhdGFzTmVlZFNob3dbaV1bMV0pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgZm9yICh2YXIgajogbnVtYmVyID0gMDsgaiA8IHRoaXMuY3VyU2hvd0RhdGFzLmxlbmd0aDsgaisrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuY3VyU2hvd0RhdGFzW2pdLnVzZXJEYXRhW3RoaXMua2V5XSA9PSBkYXRhc05lZWRTaG93W2ldWzFdW3RoaXMua2V5XSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmIChqIDwgdGhpcy5jdXJTaG93RGF0YXMubGVuZ3RoKSB7Ly/mib7liLDkuobvvIzmm7TmlrDkvY3nva5cclxuICAgICAgICAgICAgICAgIGxldCBjdXJTaG93RGF0YSA9IHRoaXMuY3VyU2hvd0RhdGFzW2pdO1xyXG4gICAgICAgICAgICAgICAgaWYgKGN1clNob3dEYXRhLmluZGV4ICE9IGRhdGFzTmVlZFNob3dbaV1bMF0pIHsvL+S9jee9ruS4jeS4gOagt1xyXG4gICAgICAgICAgICAgICAgICAgIGN1clNob3dEYXRhLmluZGV4ID0gZGF0YXNOZWVkU2hvd1tpXVswXTtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgdGFyZ2V0UG9zOiBjYy5WZWMzID0gdGhpcy5nZXRJdGVtUG9zQnlJZHgoY3VyU2hvd0RhdGEuaW5kZXgpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNjLlR3ZWVuLnN0b3BBbGxCeVRhcmdldChjdXJTaG93RGF0YS5uKTtcclxuICAgICAgICAgICAgICAgICAgICBjYy50d2VlbihjdXJTaG93RGF0YS5uKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG8oMC4xLCB7IHBvc2l0aW9uOiB0YXJnZXRQb3MgfSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgLnN0YXJ0KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdHJ1ZSA9PSBleGVjdXRlQWxsQ2FsbGJhY2sgJiYgdHJ1ZSA9PSBjYy5pc1ZhbGlkKHRoaXMuZnVuYykgJiYgdGhpcy5mdW5jKGN1clNob3dEYXRhLm4sIGN1clNob3dEYXRhLnVzZXJEYXRhLCBjdXJTaG93RGF0YS5pbmRleCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSB7Ly/msqHmib7liLDvvIzmt7vliqBcclxuICAgICAgICAgICAgICAgIGxldCBuZXdEYXRhID0gbmV3IFNjcm9sbFZpZXdQcm9EYXRhKGRhdGFzTmVlZFNob3dbaV1bMF0sIGRhdGFzTmVlZFNob3dbaV1bMV0pO1xyXG4gICAgICAgICAgICAgICAgbmV3RGF0YS5uID0gdGhpcy5ub2RlUG9vbC5wb3AoKTtcclxuICAgICAgICAgICAgICAgIGlmIChudWxsID09IG5ld0RhdGEubikge1xyXG4gICAgICAgICAgICAgICAgICAgIGRhdGFOZWVkSW5zdGFudGlhdGUucHVzaChbaSwgbmV3RGF0YV0pO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBuZXdEYXRhLm4uc2V0UG9zaXRpb24odGhpcy5nZXRJdGVtUG9zQnlJZHgobmV3RGF0YS5pbmRleCkpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY3VyU2hvd0RhdGFzLnNwbGljZShpLCAwLCBuZXdEYXRhKTsvL+a3u+WKoOS9jee9ruaYr2lcclxuICAgICAgICAgICAgICAgICAgICB0cnVlID09IGNjLmlzVmFsaWQodGhpcy5mdW5jKSAmJiB0aGlzLmZ1bmMobmV3RGF0YS5uLCBuZXdEYXRhLnVzZXJEYXRhLCBuZXdEYXRhLmluZGV4KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy/liIbluKfmt7vliqBcclxuICAgICAgICBjbGVhckludGVydmFsKHRoaXMuaW50ZXJ2YWwpO1xyXG4gICAgICAgIHRoaXMuaW50ZXJ2YWwgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChpbmRleCA+PSBkYXRhTmVlZEluc3RhbnRpYXRlLmxlbmd0aCkge1xyXG4gICAgICAgICAgICAgICAgY2xlYXJJbnRlcnZhbCh0aGlzLmludGVydmFsKTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgbGV0IG5ld0RhdGEgPSBkYXRhTmVlZEluc3RhbnRpYXRlW2luZGV4XVsxXTtcclxuICAgICAgICAgICAgbGV0IHBvcyA9IGRhdGFOZWVkSW5zdGFudGlhdGVbaW5kZXhdWzBdO1xyXG4gICAgICAgICAgICBuZXdEYXRhLm4gPSBjYy5pbnN0YW50aWF0ZSh0aGlzLml0ZW0pO1xyXG4gICAgICAgICAgICB0aGlzLmNvbnRlbnQuYWRkQ2hpbGQobmV3RGF0YS5uKTtcclxuXHJcbiAgICAgICAgICAgIG5ld0RhdGEubi5zZXRQb3NpdGlvbih0aGlzLmdldEl0ZW1Qb3NCeUlkeChuZXdEYXRhLmluZGV4KSk7XHJcbiAgICAgICAgICAgIHRoaXMuY3VyU2hvd0RhdGFzLnNwbGljZShwb3MsIDAsIG5ld0RhdGEpOy8v5re75Yqg5L2N572u5pivaVxyXG4gICAgICAgICAgICB0cnVlID09IGNjLmlzVmFsaWQodGhpcy5mdW5jKSAmJiB0aGlzLmZ1bmMobmV3RGF0YS5uLCBuZXdEYXRhLnVzZXJEYXRhLCBuZXdEYXRhLmluZGV4KTtcclxuXHJcbiAgICAgICAgICAgIGluZGV4Kys7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoq5pu05paw5oC75pWw5o2uICovXHJcbiAgICBwcml2YXRlIHVwZGF0ZUFsbERhdGFzKGRhdGFzOiBBcnJheTxhbnk+KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5hbGxEYXRhcyA9IFtdO1xyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBkYXRhcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICB0aGlzLmFsbERhdGFzLnB1c2goW2ksIGRhdGFzW2ldXSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKuabtOaWsGNvbnRlbnTlsLrlr7ggKi9cclxuICAgIHByaXZhdGUgdXBkYXRlQ29udGVudFNpemUoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKG51bGwgPT0gdGhpcy5jb250ZW50IHx8IG51bGwgPT0gdGhpcy5sYXlvdXQpIHJldHVybjtcclxuICAgICAgICBzd2l0Y2ggKHRoaXMubGF5b3V0LnR5cGUpIHtcclxuICAgICAgICAgICAgY2FzZSBjYy5MYXlvdXQuVHlwZS5WRVJUSUNBTDpcclxuICAgICAgICAgICAgICAgIHRoaXMuY29udGVudC5oZWlnaHQgPVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubGF5b3V0LnBhZGRpbmdUb3AgKyB0aGlzLmxheW91dC5wYWRkaW5nQm90dG9tICsgdGhpcy5hbGxEYXRhcy5sZW5ndGggKiAodGhpcy5sYXlvdXQuc3BhY2luZ1kgKyB0aGlzLml0ZW0uaGVpZ2h0ICogdGhpcy5pdGVtLnNjYWxlWSkgLSB0aGlzLmxheW91dC5zcGFjaW5nWTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIGNjLkxheW91dC5UeXBlLkhPUklaT05UQUw6XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbnRlbnQud2lkdGggPVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubGF5b3V0LnBhZGRpbmdMZWZ0ICsgdGhpcy5sYXlvdXQucGFkZGluZ1JpZ2h0ICsgdGhpcy5hbGxEYXRhcy5sZW5ndGggKiAodGhpcy5sYXlvdXQuc3BhY2luZ1ggKyB0aGlzLml0ZW0ud2lkdGggKiB0aGlzLml0ZW0uc2NhbGVYKSAtIHRoaXMubGF5b3V0LnNwYWNpbmdYO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgY2MuTGF5b3V0LlR5cGUuR1JJRDpcclxuICAgICAgICAgICAgICAgIC8qKuS4gOihjOacgOWkmuacieWkmuWwkeS4qiAqL1xyXG4gICAgICAgICAgICAgICAgbGV0IGNvbHMgPSBNYXRoLmZsb29yKCh0aGlzLmNvbnRlbnQud2lkdGggLSB0aGlzLmxheW91dC5wYWRkaW5nTGVmdCAtIHRoaXMubGF5b3V0LnBhZGRpbmdSaWdodCArIHRoaXMubGF5b3V0LnNwYWNpbmdYKVxyXG4gICAgICAgICAgICAgICAgICAgIC8gKHRoaXMuaXRlbS53aWR0aCAqIHRoaXMuaXRlbS5zY2FsZVggKyB0aGlzLmxheW91dC5zcGFjaW5nWCkpO1xyXG4gICAgICAgICAgICAgICAgLyoq5LiA5YWx5aSa5bCR6KGMICovXHJcbiAgICAgICAgICAgICAgICBsZXQgcm93cyA9IE1hdGguY2VpbCh0aGlzLmFsbERhdGFzLmxlbmd0aCAvIGNvbHMpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb250ZW50LmhlaWdodCA9XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5sYXlvdXQucGFkZGluZ1RvcCArIHRoaXMubGF5b3V0LnBhZGRpbmdCb3R0b20gKyByb3dzICogKHRoaXMubGF5b3V0LnNwYWNpbmdZICsgdGhpcy5pdGVtLmhlaWdodCAqIHRoaXMuaXRlbS5zY2FsZVkpIC0gdGhpcy5sYXlvdXQuc3BhY2luZ1k7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKirojrflj5bpnIDopoHlsZXnpLrnmoTmlbDmja4gKi9cclxuICAgIHByaXZhdGUgZ2V0RGF0YXNOZWVkU2hvdygpOiBBcnJheTxbbnVtYmVyLCBhbnldPiB7XHJcbiAgICAgICAgaWYgKG51bGwgPT0gdGhpcy5jb250ZW50IHx8IG51bGwgPT0gdGhpcy5sYXlvdXQpIHJldHVybiBbXTtcclxuICAgICAgICBzd2l0Y2ggKHRoaXMubGF5b3V0LnR5cGUpIHtcclxuICAgICAgICAgICAgY2FzZSBjYy5MYXlvdXQuVHlwZS5WRVJUSUNBTDpcclxuICAgICAgICAgICAgICAgIHZhciBjb250ZW50SGVhZDogbnVtYmVyID0gdGhpcy5jb250ZW50LnkgKyAoMSAtIHRoaXMuY29udGVudC5hbmNob3JZKSAqIHRoaXMuY29udGVudC5oZWlnaHQgLSAoMSAtIHRoaXMubm9kZS5hbmNob3JZKSAqIHRoaXMubm9kZS5oZWlnaHQ7XHJcbiAgICAgICAgICAgICAgICBpZiAoMCA+IGNvbnRlbnRIZWFkKSBjb250ZW50SGVhZCA9IDA7XHJcbiAgICAgICAgICAgICAgICB2YXIgY29udGVuZFRhaWw6IG51bWJlciA9IHRoaXMubm9kZS5oZWlnaHQgKyB0aGlzLmNvbnRlbnQueTtcclxuICAgICAgICAgICAgICAgIGlmIChjb250ZW5kVGFpbCA8IGNvbnRlbnRIZWFkKSBjb250ZW5kVGFpbCA9IGNvbnRlbnRIZWFkO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY29udGVudC5oZWlnaHQgLSB0aGlzLmxheW91dC5wYWRkaW5nQm90dG9tIDwgY29udGVuZFRhaWwpIGNvbnRlbmRUYWlsID0gdGhpcy5jb250ZW50LmhlaWdodCAtIHRoaXMubGF5b3V0LnBhZGRpbmdCb3R0b207XHJcblxyXG4gICAgICAgICAgICAgICAgdmFyIHN0YXJ0SW5kZXggPSBNYXRoLmZsb29yKFxyXG4gICAgICAgICAgICAgICAgICAgIChjb250ZW50SGVhZCAtIHRoaXMubGF5b3V0LnBhZGRpbmdUb3ApIC8gKHRoaXMuaXRlbS5oZWlnaHQgKyB0aGlzLmxheW91dC5zcGFjaW5nWSlcclxuICAgICAgICAgICAgICAgICk7Ly/lpJrmmL7npLrkuIDkuKpcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmFsbERhdGFzLmxlbmd0aCA8PSBzdGFydEluZGV4KSBzdGFydEluZGV4ID0gdGhpcy5hbGxEYXRhcy5sZW5ndGggLSAxO1xyXG4gICAgICAgICAgICAgICAgaWYgKDAgPiBzdGFydEluZGV4KSBzdGFydEluZGV4ID0gMDtcclxuXHJcbiAgICAgICAgICAgICAgICB2YXIgZW5kSW5kZXggPSBNYXRoLmNlaWwoXHJcbiAgICAgICAgICAgICAgICAgICAgKGNvbnRlbmRUYWlsIC0gdGhpcy5sYXlvdXQucGFkZGluZ1RvcCkgLyAodGhpcy5pdGVtLmhlaWdodCArIHRoaXMubGF5b3V0LnNwYWNpbmdZKVxyXG4gICAgICAgICAgICAgICAgKTsvL+WkmuaYvuekuuS4gOS4qlxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuYWxsRGF0YXMubGVuZ3RoIDw9IGVuZEluZGV4KSBlbmRJbmRleCA9IHRoaXMuYWxsRGF0YXMubGVuZ3RoIC0gMTtcclxuICAgICAgICAgICAgICAgIGlmIChlbmRJbmRleCA8IHN0YXJ0SW5kZXgpIGVuZEluZGV4ID0gc3RhcnRJbmRleDtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIGNjLkxheW91dC5UeXBlLkhPUklaT05UQUw6XHJcbiAgICAgICAgICAgICAgICB2YXIgY29udGVudEhlYWQ6IG51bWJlciA9IC0odGhpcy5jb250ZW50LnggLSB0aGlzLmNvbnRlbnQuYW5jaG9yWCAqIHRoaXMuY29udGVudC53aWR0aCkgKyB0aGlzLm5vZGUuYW5jaG9yWCAqIHRoaXMubm9kZS53aWR0aDtcclxuICAgICAgICAgICAgICAgIGlmICgwID4gY29udGVudEhlYWQpIGNvbnRlbnRIZWFkID0gMDtcclxuICAgICAgICAgICAgICAgIHZhciBjb250ZW5kVGFpbDogbnVtYmVyID0gdGhpcy5ub2RlLndpZHRoIC0gdGhpcy5jb250ZW50Lng7XHJcbiAgICAgICAgICAgICAgICBpZiAoY29udGVuZFRhaWwgPCBjb250ZW50SGVhZCkgY29udGVuZFRhaWwgPSBjb250ZW50SGVhZDtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbnRlbnQud2lkdGggLSB0aGlzLmxheW91dC5wYWRkaW5nUmlnaHQgPCBjb250ZW5kVGFpbCkgY29udGVuZFRhaWwgPSB0aGlzLmNvbnRlbnQud2lkdGggLSB0aGlzLmxheW91dC5wYWRkaW5nUmlnaHQ7XHJcblxyXG4gICAgICAgICAgICAgICAgdmFyIHN0YXJ0SW5kZXggPSBNYXRoLmZsb29yKFxyXG4gICAgICAgICAgICAgICAgICAgIChjb250ZW50SGVhZCAtIHRoaXMubGF5b3V0LnBhZGRpbmdMZWZ0KSAvICh0aGlzLml0ZW0ud2lkdGggKyB0aGlzLmxheW91dC5zcGFjaW5nWClcclxuICAgICAgICAgICAgICAgICk7Ly/lpJrmmL7npLrkuIDkuKpcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmFsbERhdGFzLmxlbmd0aCA8PSBzdGFydEluZGV4KSBzdGFydEluZGV4ID0gdGhpcy5hbGxEYXRhcy5sZW5ndGggLSAxO1xyXG4gICAgICAgICAgICAgICAgaWYgKDAgPiBzdGFydEluZGV4KSBzdGFydEluZGV4ID0gMDtcclxuXHJcbiAgICAgICAgICAgICAgICB2YXIgZW5kSW5kZXggPSBNYXRoLmNlaWwoXHJcbiAgICAgICAgICAgICAgICAgICAgKGNvbnRlbmRUYWlsIC0gdGhpcy5sYXlvdXQucGFkZGluZ0xlZnQpIC8gKHRoaXMuaXRlbS53aWR0aCArIHRoaXMubGF5b3V0LnNwYWNpbmdYKVxyXG4gICAgICAgICAgICAgICAgKTsvL+WkmuaYvuekuuS4gOS4qlxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuYWxsRGF0YXMubGVuZ3RoIDw9IGVuZEluZGV4KSBlbmRJbmRleCA9IHRoaXMuYWxsRGF0YXMubGVuZ3RoIC0gMTtcclxuICAgICAgICAgICAgICAgIGlmIChlbmRJbmRleCA8IHN0YXJ0SW5kZXgpIGVuZEluZGV4ID0gc3RhcnRJbmRleDtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIGNjLkxheW91dC5UeXBlLkdSSUQ6XHJcbiAgICAgICAgICAgICAgICB2YXIgY29udGVudEhlYWQ6IG51bWJlciA9IHRoaXMuY29udGVudC55ICsgKDEgLSB0aGlzLmNvbnRlbnQuYW5jaG9yWSkgKiB0aGlzLmNvbnRlbnQuaGVpZ2h0IC0gKDEgLSB0aGlzLm5vZGUuYW5jaG9yWSkgKiB0aGlzLm5vZGUuaGVpZ2h0O1xyXG4gICAgICAgICAgICAgICAgaWYgKDAgPiBjb250ZW50SGVhZCkgY29udGVudEhlYWQgPSAwO1xyXG4gICAgICAgICAgICAgICAgdmFyIGNvbnRlbmRUYWlsOiBudW1iZXIgPSB0aGlzLm5vZGUuaGVpZ2h0ICsgdGhpcy5jb250ZW50Lnk7XHJcbiAgICAgICAgICAgICAgICBpZiAoY29udGVuZFRhaWwgPCBjb250ZW50SGVhZCkgY29udGVuZFRhaWwgPSBjb250ZW50SGVhZDtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbnRlbnQuaGVpZ2h0IC0gdGhpcy5sYXlvdXQucGFkZGluZ0JvdHRvbSA8IGNvbnRlbmRUYWlsKSBjb250ZW5kVGFpbCA9IHRoaXMuY29udGVudC5oZWlnaHQgLSB0aGlzLmxheW91dC5wYWRkaW5nQm90dG9tO1xyXG5cclxuICAgICAgICAgICAgICAgIC8qKuS4gOihjOacgOWkmuacieWkmuWwkeS4qiAqL1xyXG4gICAgICAgICAgICAgICAgbGV0IGNvbHMgPSBNYXRoLmZsb29yKCh0aGlzLmNvbnRlbnQud2lkdGggLSB0aGlzLmxheW91dC5wYWRkaW5nTGVmdCAtIHRoaXMubGF5b3V0LnBhZGRpbmdSaWdodCArIHRoaXMubGF5b3V0LnNwYWNpbmdYKVxyXG4gICAgICAgICAgICAgICAgICAgIC8gKHRoaXMuaXRlbS53aWR0aCArIHRoaXMubGF5b3V0LnNwYWNpbmdYKSk7XHJcbiAgICAgICAgICAgICAgICB2YXIgc3RhcnRJbmRleCA9IE1hdGguZmxvb3IoXHJcbiAgICAgICAgICAgICAgICAgICAgKGNvbnRlbnRIZWFkIC0gdGhpcy5sYXlvdXQucGFkZGluZ1RvcCkgLyAodGhpcy5pdGVtLmhlaWdodCArIHRoaXMubGF5b3V0LnNwYWNpbmdZKVxyXG4gICAgICAgICAgICAgICAgKSAqIGNvbHM7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5hbGxEYXRhcy5sZW5ndGggPD0gc3RhcnRJbmRleCkgc3RhcnRJbmRleCA9IHRoaXMuYWxsRGF0YXMubGVuZ3RoIC0gMTtcclxuICAgICAgICAgICAgICAgIGlmICgwID4gc3RhcnRJbmRleCkgc3RhcnRJbmRleCA9IDA7XHJcblxyXG4gICAgICAgICAgICAgICAgdmFyIGVuZEluZGV4ID0gTWF0aC5jZWlsKFxyXG4gICAgICAgICAgICAgICAgICAgIChjb250ZW5kVGFpbCAtIHRoaXMubGF5b3V0LnBhZGRpbmdUb3ApIC8gKHRoaXMuaXRlbS5oZWlnaHQgKyB0aGlzLmxheW91dC5zcGFjaW5nWSlcclxuICAgICAgICAgICAgICAgICkgKiBjb2xzIC0gMTtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmFsbERhdGFzLmxlbmd0aCA8PSBlbmRJbmRleCkgZW5kSW5kZXggPSB0aGlzLmFsbERhdGFzLmxlbmd0aCAtIDE7XHJcbiAgICAgICAgICAgICAgICBpZiAoZW5kSW5kZXggPCBzdGFydEluZGV4KSBlbmRJbmRleCA9IHN0YXJ0SW5kZXg7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IHJldDogQXJyYXk8W251bWJlciwgYW55XT4gPSBbXTtcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSBzdGFydEluZGV4OyBpIDwgTWF0aC5taW4odGhpcy5hbGxEYXRhcy5sZW5ndGgsIGVuZEluZGV4ICsgMSk7IGkrKykge1xyXG4gICAgICAgICAgICByZXQucHVzaCh0aGlzLmFsbERhdGFzW2ldKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHJldDtcclxuICAgIH1cclxuXHJcbiAgICAvKirmoLnmja7oioLngrnkuIvmoIfojrflj5boioLngrnlupTor6XmiYDlpITnmoTkvY3nva4gKi9cclxuICAgIHByaXZhdGUgZ2V0SXRlbVBvc0J5SWR4KGluZGV4OiBudW1iZXIpOiBjYy5WZWMzIHtcclxuICAgICAgICBpZiAobnVsbCA9PSB0aGlzLmNvbnRlbnQgfHwgbnVsbCA9PSB0aGlzLmxheW91dCkgcmV0dXJuIGNjLnYzKCk7XHJcbiAgICAgICAgc3dpdGNoICh0aGlzLmxheW91dC50eXBlKSB7XHJcbiAgICAgICAgICAgIGNhc2UgY2MuTGF5b3V0LlR5cGUuVkVSVElDQUw6XHJcbiAgICAgICAgICAgICAgICB2YXIgZGVsdGFZID0gdGhpcy5sYXlvdXQucGFkZGluZ1RvcFxyXG4gICAgICAgICAgICAgICAgICAgICsgKDEgLSB0aGlzLmNvbnRlbnQuYW5jaG9yWSkgKiB0aGlzLmNvbnRlbnQuaGVpZ2h0XHJcbiAgICAgICAgICAgICAgICAgICAgKyAoMSAtIHRoaXMuaXRlbS5hbmNob3JZKSAqIHRoaXMuaXRlbS5oZWlnaHQgKiB0aGlzLml0ZW0uc2NhbGVZXHJcbiAgICAgICAgICAgICAgICAgICAgKyBpbmRleCAqICh0aGlzLml0ZW0uaGVpZ2h0ICogdGhpcy5pdGVtLnNjYWxlWSArIHRoaXMubGF5b3V0LnNwYWNpbmdZKTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBjYy52MygwLCAtZGVsdGFZLCAwKTtcclxuICAgICAgICAgICAgY2FzZSBjYy5MYXlvdXQuVHlwZS5IT1JJWk9OVEFMOlxyXG4gICAgICAgICAgICAgICAgdmFyIGRlbHRhWCA9IHRoaXMubGF5b3V0LnBhZGRpbmdMZWZ0XHJcbiAgICAgICAgICAgICAgICAgICAgLSB0aGlzLmNvbnRlbnQuYW5jaG9yWCAqIHRoaXMuY29udGVudC53aWR0aFxyXG4gICAgICAgICAgICAgICAgICAgICsgKHRoaXMuaXRlbS5hbmNob3JYKSAqIHRoaXMuaXRlbS53aWR0aCAqIHRoaXMuaXRlbS5zY2FsZVhcclxuICAgICAgICAgICAgICAgICAgICArIGluZGV4ICogKHRoaXMuaXRlbS53aWR0aCAqIHRoaXMuaXRlbS5zY2FsZVggKyB0aGlzLmxheW91dC5zcGFjaW5nWCk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gY2MudjMoZGVsdGFYLCAwLCAwKTtcclxuICAgICAgICAgICAgY2FzZSBjYy5MYXlvdXQuVHlwZS5HUklEOlxyXG4gICAgICAgICAgICAgICAgLyoq5LiA6KGM5pyA5aSa5pyJ5aSa5bCR5LiqICovXHJcbiAgICAgICAgICAgICAgICBsZXQgY29scyA9IE1hdGguZmxvb3IoKHRoaXMuY29udGVudC53aWR0aCAtIHRoaXMubGF5b3V0LnBhZGRpbmdMZWZ0IC0gdGhpcy5sYXlvdXQucGFkZGluZ1JpZ2h0ICsgdGhpcy5sYXlvdXQuc3BhY2luZ1gpXHJcbiAgICAgICAgICAgICAgICAgICAgLyAodGhpcy5pdGVtLndpZHRoICogdGhpcy5pdGVtLnNjYWxlWCArIHRoaXMubGF5b3V0LnNwYWNpbmdYKSk7XHJcbiAgICAgICAgICAgICAgICB2YXIgZGVsdGFZID0gdGhpcy5sYXlvdXQucGFkZGluZ1RvcFxyXG4gICAgICAgICAgICAgICAgICAgICsgKDEgLSB0aGlzLmNvbnRlbnQuYW5jaG9yWSkgKiB0aGlzLmNvbnRlbnQuaGVpZ2h0XHJcbiAgICAgICAgICAgICAgICAgICAgKyAoMSAtIHRoaXMuaXRlbS5hbmNob3JZKSAqIHRoaXMuaXRlbS5oZWlnaHQgKiB0aGlzLml0ZW0uc2NhbGVZXHJcbiAgICAgICAgICAgICAgICAgICAgKyBNYXRoLmZsb29yKGluZGV4IC8gY29scykgKiAodGhpcy5pdGVtLmhlaWdodCAqIHRoaXMuaXRlbS5zY2FsZVkgKyB0aGlzLmxheW91dC5zcGFjaW5nWSk7XHJcbiAgICAgICAgICAgICAgICB2YXIgZGVsdGFYID0gdGhpcy5sYXlvdXQucGFkZGluZ0xlZnRcclxuICAgICAgICAgICAgICAgICAgICArICh0aGlzLml0ZW0uYW5jaG9yWCAqIHRoaXMuaXRlbS53aWR0aCAqIHRoaXMuaXRlbS5zY2FsZVgpIC0gdGhpcy5jb250ZW50LmFuY2hvclggKiB0aGlzLmNvbnRlbnQud2lkdGhcclxuICAgICAgICAgICAgICAgICAgICArIChpbmRleCAlIGNvbHMpICogKHRoaXMuaXRlbS53aWR0aCAqIHRoaXMuaXRlbS5zY2FsZVggKyB0aGlzLmxheW91dC5zcGFjaW5nWClcclxuICAgICAgICAgICAgICAgIHJldHVybiBjYy52MyhkZWx0YVgsIC1kZWx0YVksIDApO1xyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGNjLnYzKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5jbGFzcyBTY3JvbGxWaWV3UHJvRGF0YSB7XHJcbiAgICBuOiBjYy5Ob2RlO1xyXG4gICAgLyoq55So5oi35pWw5o2uICovXHJcbiAgICB1c2VyRGF0YTogYW55O1xyXG4gICAgLyoq6IqC54K55Zyo5pWw5o2u5Lit55qE5LiL5qCH77yM5qC55o2uaW5kZXjosIPmlbToioLngrnlnKhjb250ZW505Lit55qE5L2N572uICovXHJcbiAgICBpbmRleDogbnVtYmVyO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKGluZGV4OiBudW1iZXIsIHVzZXJEYXRhOiBhbnkpIHtcclxuICAgICAgICB0aGlzLmluZGV4ID0gaW5kZXg7XHJcbiAgICAgICAgdGhpcy51c2VyRGF0YSA9IHVzZXJEYXRhO1xyXG4gICAgfVxyXG59Il19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Helloworld.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e1b90/rohdEk4SdmmEZANaD', 'Helloworld');
// Script/Helloworld.ts

Object.defineProperty(exports, "__esModule", { value: true });
var ScrollViewProCom_1 = require("./ScrollViewProCom");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Helloworld = /** @class */ (function (_super) {
    __extends(Helloworld, _super);
    function Helloworld() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.scrollviewVertical = null;
        _this.scrollviewHorizontal = null;
        _this.scrollviewGrid = null;
        return _this;
    }
    Helloworld.prototype.start = function () {
        // init logic
        var datas = [];
        for (var i = 0; i < 1000; i++) {
            datas.push(i);
        }
        this.scrollviewVertical && this.scrollviewVertical.setView(datas, function (n, data, index) {
            var label = n.getComponentInChildren(cc.Label);
            label && (label.string = "NO." + data);
        });
        this.scrollviewHorizontal && this.scrollviewHorizontal.setView(datas, function (n, data, index) {
            var label = n.getComponentInChildren(cc.Label);
            label && (label.string = "NO." + data);
        });
        this.scrollviewGrid && this.scrollviewGrid.setView(datas, function (n, data, index) {
            var label = n.getComponentInChildren(cc.Label);
            label && (label.string = "NO." + data);
        });
    };
    __decorate([
        property({ type: ScrollViewProCom_1.default, displayName: "垂直布局列表" })
    ], Helloworld.prototype, "scrollviewVertical", void 0);
    __decorate([
        property({ type: ScrollViewProCom_1.default, displayName: "水平布局列表" })
    ], Helloworld.prototype, "scrollviewHorizontal", void 0);
    __decorate([
        property({ type: ScrollViewProCom_1.default, displayName: "网格布局列表" })
    ], Helloworld.prototype, "scrollviewGrid", void 0);
    Helloworld = __decorate([
        ccclass
    ], Helloworld);
    return Helloworld;
}(cc.Component));
exports.default = Helloworld;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TY3JpcHQvSGVsbG93b3JsZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsdURBQWtEO0FBRTVDLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDO0lBQXdDLDhCQUFZO0lBQXBEO1FBQUEscUVBOEJDO1FBM0JXLHdCQUFrQixHQUFxQixJQUFJLENBQUM7UUFFNUMsMEJBQW9CLEdBQXFCLElBQUksQ0FBQztRQUU5QyxvQkFBYyxHQUFxQixJQUFJLENBQUM7O0lBdUJwRCxDQUFDO0lBckJHLDBCQUFLLEdBQUw7UUFDSSxhQUFhO1FBQ2IsSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFDO1FBQ2YsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNuQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ2pCO1FBQ0QsSUFBSSxDQUFDLGtCQUFrQixJQUFJLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLFVBQUMsQ0FBVSxFQUFFLElBQVksRUFBRSxLQUFhO1lBQ3RHLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDL0MsS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxRQUFNLElBQU0sQ0FBQyxDQUFDO1FBQzNDLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLG9CQUFvQixJQUFJLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLFVBQUMsQ0FBVSxFQUFFLElBQVksRUFBRSxLQUFhO1lBQzFHLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDL0MsS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxRQUFNLElBQU0sQ0FBQyxDQUFDO1FBQzNDLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLGNBQWMsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsVUFBQyxDQUFVLEVBQUUsSUFBWSxFQUFFLEtBQWE7WUFDOUYsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUMvQyxLQUFLLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLFFBQU0sSUFBTSxDQUFDLENBQUM7UUFDM0MsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBMUJEO1FBREMsUUFBUSxDQUFDLEVBQUUsSUFBSSxFQUFFLDBCQUFnQixFQUFFLFdBQVcsRUFBRSxRQUFRLEVBQUUsQ0FBQzswREFDUjtJQUVwRDtRQURDLFFBQVEsQ0FBQyxFQUFFLElBQUksRUFBRSwwQkFBZ0IsRUFBRSxXQUFXLEVBQUUsUUFBUSxFQUFFLENBQUM7NERBQ047SUFFdEQ7UUFEQyxRQUFRLENBQUMsRUFBRSxJQUFJLEVBQUUsMEJBQWdCLEVBQUUsV0FBVyxFQUFFLFFBQVEsRUFBRSxDQUFDO3NEQUNaO0lBUC9CLFVBQVU7UUFEOUIsT0FBTztPQUNhLFVBQVUsQ0E4QjlCO0lBQUQsaUJBQUM7Q0E5QkQsQUE4QkMsQ0E5QnVDLEVBQUUsQ0FBQyxTQUFTLEdBOEJuRDtrQkE5Qm9CLFVBQVUiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgU2Nyb2xsVmlld1Byb0NvbSBmcm9tIFwiLi9TY3JvbGxWaWV3UHJvQ29tXCI7XHJcblxyXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgSGVsbG93b3JsZCBleHRlbmRzIGNjLkNvbXBvbmVudCB7XHJcblxyXG4gICAgQHByb3BlcnR5KHsgdHlwZTogU2Nyb2xsVmlld1Byb0NvbSwgZGlzcGxheU5hbWU6IFwi5Z6C55u05biD5bGA5YiX6KGoXCIgfSlcclxuICAgIHByaXZhdGUgc2Nyb2xsdmlld1ZlcnRpY2FsOiBTY3JvbGxWaWV3UHJvQ29tID0gbnVsbDtcclxuICAgIEBwcm9wZXJ0eSh7IHR5cGU6IFNjcm9sbFZpZXdQcm9Db20sIGRpc3BsYXlOYW1lOiBcIuawtOW5s+W4g+WxgOWIl+ihqFwiIH0pXHJcbiAgICBwcml2YXRlIHNjcm9sbHZpZXdIb3Jpem9udGFsOiBTY3JvbGxWaWV3UHJvQ29tID0gbnVsbDtcclxuICAgIEBwcm9wZXJ0eSh7IHR5cGU6IFNjcm9sbFZpZXdQcm9Db20sIGRpc3BsYXlOYW1lOiBcIue9keagvOW4g+WxgOWIl+ihqFwiIH0pXHJcbiAgICBwcml2YXRlIHNjcm9sbHZpZXdHcmlkOiBTY3JvbGxWaWV3UHJvQ29tID0gbnVsbDtcclxuXHJcbiAgICBzdGFydCgpIHtcclxuICAgICAgICAvLyBpbml0IGxvZ2ljXHJcbiAgICAgICAgbGV0IGRhdGFzID0gW107XHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IDEwMDA7IGkrKykge1xyXG4gICAgICAgICAgICBkYXRhcy5wdXNoKGkpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLnNjcm9sbHZpZXdWZXJ0aWNhbCAmJiB0aGlzLnNjcm9sbHZpZXdWZXJ0aWNhbC5zZXRWaWV3KGRhdGFzLCAobjogY2MuTm9kZSwgZGF0YTogbnVtYmVyLCBpbmRleDogbnVtYmVyKSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBsYWJlbCA9IG4uZ2V0Q29tcG9uZW50SW5DaGlsZHJlbihjYy5MYWJlbCk7XHJcbiAgICAgICAgICAgIGxhYmVsICYmIChsYWJlbC5zdHJpbmcgPSBgTk8uJHtkYXRhfWApO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGlzLnNjcm9sbHZpZXdIb3Jpem9udGFsICYmIHRoaXMuc2Nyb2xsdmlld0hvcml6b250YWwuc2V0VmlldyhkYXRhcywgKG46IGNjLk5vZGUsIGRhdGE6IG51bWJlciwgaW5kZXg6IG51bWJlcikgPT4ge1xyXG4gICAgICAgICAgICBsZXQgbGFiZWwgPSBuLmdldENvbXBvbmVudEluQ2hpbGRyZW4oY2MuTGFiZWwpO1xyXG4gICAgICAgICAgICBsYWJlbCAmJiAobGFiZWwuc3RyaW5nID0gYE5PLiR7ZGF0YX1gKTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5zY3JvbGx2aWV3R3JpZCAmJiB0aGlzLnNjcm9sbHZpZXdHcmlkLnNldFZpZXcoZGF0YXMsIChuOiBjYy5Ob2RlLCBkYXRhOiBudW1iZXIsIGluZGV4OiBudW1iZXIpID0+IHtcclxuICAgICAgICAgICAgbGV0IGxhYmVsID0gbi5nZXRDb21wb25lbnRJbkNoaWxkcmVuKGNjLkxhYmVsKTtcclxuICAgICAgICAgICAgbGFiZWwgJiYgKGxhYmVsLnN0cmluZyA9IGBOTy4ke2RhdGF9YCk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbn1cclxuIl19
//------QC-SOURCE-SPLIT------
