import ScrollViewProCom from "./ScrollViewProCom";

const { ccclass, property } = cc._decorator;

@ccclass
export default class Helloworld extends cc.Component {

    @property({ type: ScrollViewProCom, displayName: "垂直布局列表" })
    private scrollviewVertical: ScrollViewProCom = null;
    @property({ type: ScrollViewProCom, displayName: "水平布局列表" })
    private scrollviewHorizontal: ScrollViewProCom = null;
    @property({ type: ScrollViewProCom, displayName: "网格布局列表" })
    private scrollviewGrid: ScrollViewProCom = null;

    start() {
        // init logic
        let datas = [];
        for (let i: number = 0; i < 1000; i++) {
            datas.push(i);
        }
        this.scrollviewVertical && this.scrollviewVertical.setView(datas, (n: cc.Node, data: number, index: number) => {
            let label = n.getComponentInChildren(cc.Label);
            label && (label.string = `NO.${data}`);
        });

        this.scrollviewHorizontal && this.scrollviewHorizontal.setView(datas, (n: cc.Node, data: number, index: number) => {
            let label = n.getComponentInChildren(cc.Label);
            label && (label.string = `NO.${data}`);
        });

        this.scrollviewGrid && this.scrollviewGrid.setView(datas, (n: cc.Node, data: number, index: number) => {
            let label = n.getComponentInChildren(cc.Label);
            label && (label.string = `NO.${data}`);
        });
    }
}
