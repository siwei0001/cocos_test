const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("用户脚本组件/滚动视图优化组件")
export default class ScrollViewProCom extends cc.Component {
    @property({ type: cc.Enum({ 节点: 0, 预制体: 1 }), displayName: "item类型" })
    private type: number = 0;
    @property({
        type: cc.Node, visible() {
            return this.type == 0;
        }, displayName: "item节点"
    })
    private itemNode: cc.Node = null;
    @property({
        type: cc.Prefab, visible() {
            return this.type == 1;
        }, displayName: "item预制体"
    })
    private itemPrefab: cc.Prefab = null;

    private comScrollView: cc.ScrollView;
    private content: cc.Node;
    private layout: cc.Layout;
    private _item: cc.Node;
    private nodePool: Array<cc.Node>;
    private interval: number;

    private curShowDatas: Array<ScrollViewProData> = [];

    private allDatas: Array<[number, any]> = [];
    private func: Function;
    private key: string;
    protected onLoad(): void {
        this.comScrollView = this.node.getComponent(cc.ScrollView);
        if (null == this.comScrollView) return;
        this.content = this.comScrollView.content;
        if (null == this.content) return;
        this.layout = this.content.getComponent(cc.Layout);
        if (null == this.layout) return;
        this.layout.enabled = false;

        this.node.on("scrolling", this.onScrolling, this);
        this.node.on(cc.Node.EventType.SIZE_CHANGED, this.onSizeChanged, this);
        this.nodePool = [];
        for (let i: number = this.content.childrenCount - 1; i >= 0; i--) {
            this.nodePool.push(this.content.children[i]);
            this.content.children[i].setPosition(Number.MAX_VALUE, Number.MAX_VALUE);
        }
        this.updateContentSize();
        this.updateListView();
    }

    protected onDestroy(): void {
        this.node.off("scrolling", this.onScrolling, this);
        this.node.off(cc.Node.EventType.SIZE_CHANGED, this.onSizeChanged, this);
        clearInterval(this.interval);
    }

    /**
     * 设置视图
     * @param datas 用户数据
     * @param func 回调
     * @param key 根据key查询两次数据是否一样
     */
    public setView(datas: Array<any>, func: (n: cc.Node, data: any, index: number) => void, key?: string): void {
        this.updateAllDatas(datas);
        this.func = func, this.key = key;
        this.updateContentSize();
        this.updateListView(true);
    }

    private onSizeChanged(): void {
        this.updateListView();
    }

    private onScrolling(): void {
        this.updateListView();
    }

    private get item(): cc.Node {
        if (null == this._item) {
            if (0 == this.type && null != this.itemNode) {
                this._item = cc.instantiate(this.itemNode);
            } else if (1 == this.type && null != this.itemPrefab) {
                this._item = cc.instantiate(this.itemPrefab);
            }
        }

        return this._item;
    }

    /**更新view */
    private updateListView(executeAllCallback: boolean = false): void {
        let datasNeedShow = this.getDatasNeedShow();
        //先把当前展示的item中不需要的移除
        for (let i: number = this.curShowDatas.length - 1; i >= 0; i--) {
            if (null == this.key) {
                for (var j = 0; j < datasNeedShow.length; j++) {
                    if (datasNeedShow[j][1] == this.curShowDatas[i].userData) {
                        break;
                    }
                }
            } else {
                for (var j = 0; j < datasNeedShow.length; j++) {
                    if (datasNeedShow[j][1][this.key] == this.curShowDatas[i].userData[this.key]) {
                        break;
                    }
                }
            }

            if (j >= datasNeedShow.length) {//不再需要了
                this.nodePool.push(this.curShowDatas[i].n);
                this.curShowDatas[i].n.setPosition(Number.MAX_VALUE, Number.MAX_VALUE);
                this.curShowDatas.splice(i, 1);
            }
        }

        let dataNeedInstantiate: Array<Array<any>> = [];
        let index: number = 0;
        //再添加需要显示的item和更新现有item的坐标
        for (let i: number = 0; i < datasNeedShow.length; i++) {
            if (null == this.key) {
                for (var j: number = 0; j < this.curShowDatas.length; j++) {
                    if (this.curShowDatas[j].userData == datasNeedShow[i][1]) {
                        break;
                    }
                }
            } else {
                for (var j: number = 0; j < this.curShowDatas.length; j++) {
                    if (this.curShowDatas[j].userData[this.key] == datasNeedShow[i][1][this.key]) {
                        break;
                    }
                }
            }

            if (j < this.curShowDatas.length) {//找到了，更新位置
                let curShowData = this.curShowDatas[j];
                if (curShowData.index != datasNeedShow[i][0]) {//位置不一样
                    curShowData.index = datasNeedShow[i][0];
                    let targetPos: cc.Vec3 = this.getItemPosByIdx(curShowData.index);
                    cc.Tween.stopAllByTarget(curShowData.n);
                    cc.tween(curShowData.n)
                        .to(0.1, { position: targetPos })
                        .start();
                    true == executeAllCallback && true == cc.isValid(this.func) && this.func(curShowData.n, curShowData.userData, curShowData.index);
                }
            } else {//没找到，添加
                let newData = new ScrollViewProData(datasNeedShow[i][0], datasNeedShow[i][1]);
                newData.n = this.nodePool.pop();
                if (null == newData.n) {
                    dataNeedInstantiate.push([i, newData]);
                } else {
                    newData.n.setPosition(this.getItemPosByIdx(newData.index));
                    this.curShowDatas.splice(i, 0, newData);//添加位置是i
                    true == cc.isValid(this.func) && this.func(newData.n, newData.userData, newData.index);
                }
            }
        }

        //分帧添加
        clearInterval(this.interval);
        this.interval = setInterval(() => {
            if (index >= dataNeedInstantiate.length) {
                clearInterval(this.interval);
                return;
            }

            let newData = dataNeedInstantiate[index][1];
            let pos = dataNeedInstantiate[index][0];
            newData.n = cc.instantiate(this.item);
            this.content.addChild(newData.n);

            newData.n.setPosition(this.getItemPosByIdx(newData.index));
            this.curShowDatas.splice(pos, 0, newData);//添加位置是i
            true == cc.isValid(this.func) && this.func(newData.n, newData.userData, newData.index);

            index++;
        });
    }

    /**更新总数据 */
    private updateAllDatas(datas: Array<any>): void {
        this.allDatas = [];
        for (let i: number = 0; i < datas.length; i++) {
            this.allDatas.push([i, datas[i]]);
        }
    }

    /**更新content尺寸 */
    private updateContentSize(): void {
        if (null == this.content || null == this.layout) return;
        switch (this.layout.type) {
            case cc.Layout.Type.VERTICAL:
                this.content.height =
                    this.layout.paddingTop + this.layout.paddingBottom + this.allDatas.length * (this.layout.spacingY + this.item.height * this.item.scaleY) - this.layout.spacingY;
                break;
            case cc.Layout.Type.HORIZONTAL:
                this.content.width =
                    this.layout.paddingLeft + this.layout.paddingRight + this.allDatas.length * (this.layout.spacingX + this.item.width * this.item.scaleX) - this.layout.spacingX;
                break;
            case cc.Layout.Type.GRID:
                /**一行最多有多少个 */
                let cols = Math.floor((this.content.width - this.layout.paddingLeft - this.layout.paddingRight + this.layout.spacingX)
                    / (this.item.width * this.item.scaleX + this.layout.spacingX));
                /**一共多少行 */
                let rows = Math.ceil(this.allDatas.length / cols);
                this.content.height =
                    this.layout.paddingTop + this.layout.paddingBottom + rows * (this.layout.spacingY + this.item.height * this.item.scaleY) - this.layout.spacingY;
                break;
            default:
                break;
        }
    }

    /**获取需要展示的数据 */
    private getDatasNeedShow(): Array<[number, any]> {
        if (null == this.content || null == this.layout) return [];
        switch (this.layout.type) {
            case cc.Layout.Type.VERTICAL:
                var contentHead: number = this.content.y + (1 - this.content.anchorY) * this.content.height - (1 - this.node.anchorY) * this.node.height;
                if (0 > contentHead) contentHead = 0;
                var contendTail: number = this.node.height + this.content.y;
                if (contendTail < contentHead) contendTail = contentHead;
                if (this.content.height - this.layout.paddingBottom < contendTail) contendTail = this.content.height - this.layout.paddingBottom;

                var startIndex = Math.floor(
                    (contentHead - this.layout.paddingTop) / (this.item.height + this.layout.spacingY)
                );//多显示一个
                if (this.allDatas.length <= startIndex) startIndex = this.allDatas.length - 1;
                if (0 > startIndex) startIndex = 0;

                var endIndex = Math.ceil(
                    (contendTail - this.layout.paddingTop) / (this.item.height + this.layout.spacingY)
                );//多显示一个
                if (this.allDatas.length <= endIndex) endIndex = this.allDatas.length - 1;
                if (endIndex < startIndex) endIndex = startIndex;
                break;
            case cc.Layout.Type.HORIZONTAL:
                var contentHead: number = -(this.content.x - this.content.anchorX * this.content.width) + this.node.anchorX * this.node.width;
                if (0 > contentHead) contentHead = 0;
                var contendTail: number = this.node.width - this.content.x;
                if (contendTail < contentHead) contendTail = contentHead;
                if (this.content.width - this.layout.paddingRight < contendTail) contendTail = this.content.width - this.layout.paddingRight;

                var startIndex = Math.floor(
                    (contentHead - this.layout.paddingLeft) / (this.item.width + this.layout.spacingX)
                );//多显示一个
                if (this.allDatas.length <= startIndex) startIndex = this.allDatas.length - 1;
                if (0 > startIndex) startIndex = 0;

                var endIndex = Math.ceil(
                    (contendTail - this.layout.paddingLeft) / (this.item.width + this.layout.spacingX)
                );//多显示一个
                if (this.allDatas.length <= endIndex) endIndex = this.allDatas.length - 1;
                if (endIndex < startIndex) endIndex = startIndex;
                break;
            case cc.Layout.Type.GRID:
                var contentHead: number = this.content.y + (1 - this.content.anchorY) * this.content.height - (1 - this.node.anchorY) * this.node.height;
                if (0 > contentHead) contentHead = 0;
                var contendTail: number = this.node.height + this.content.y;
                if (contendTail < contentHead) contendTail = contentHead;
                if (this.content.height - this.layout.paddingBottom < contendTail) contendTail = this.content.height - this.layout.paddingBottom;

                /**一行最多有多少个 */
                let cols = Math.floor((this.content.width - this.layout.paddingLeft - this.layout.paddingRight + this.layout.spacingX)
                    / (this.item.width + this.layout.spacingX));
                var startIndex = Math.floor(
                    (contentHead - this.layout.paddingTop) / (this.item.height + this.layout.spacingY)
                ) * cols;
                if (this.allDatas.length <= startIndex) startIndex = this.allDatas.length - 1;
                if (0 > startIndex) startIndex = 0;

                var endIndex = Math.ceil(
                    (contendTail - this.layout.paddingTop) / (this.item.height + this.layout.spacingY)
                ) * cols - 1;
                if (this.allDatas.length <= endIndex) endIndex = this.allDatas.length - 1;
                if (endIndex < startIndex) endIndex = startIndex;
                break;
            default:
                break;
        }

        let ret: Array<[number, any]> = [];
        for (let i: number = startIndex; i < Math.min(this.allDatas.length, endIndex + 1); i++) {
            ret.push(this.allDatas[i]);
        }
        return ret;
    }

    /**根据节点下标获取节点应该所处的位置 */
    private getItemPosByIdx(index: number): cc.Vec3 {
        if (null == this.content || null == this.layout) return cc.v3();
        switch (this.layout.type) {
            case cc.Layout.Type.VERTICAL:
                var deltaY = this.layout.paddingTop
                    + (1 - this.content.anchorY) * this.content.height
                    + (1 - this.item.anchorY) * this.item.height * this.item.scaleY
                    + index * (this.item.height * this.item.scaleY + this.layout.spacingY);
                return cc.v3(0, -deltaY, 0);
            case cc.Layout.Type.HORIZONTAL:
                var deltaX = this.layout.paddingLeft
                    - this.content.anchorX * this.content.width
                    + (this.item.anchorX) * this.item.width * this.item.scaleX
                    + index * (this.item.width * this.item.scaleX + this.layout.spacingX);
                return cc.v3(deltaX, 0, 0);
            case cc.Layout.Type.GRID:
                /**一行最多有多少个 */
                let cols = Math.floor((this.content.width - this.layout.paddingLeft - this.layout.paddingRight + this.layout.spacingX)
                    / (this.item.width * this.item.scaleX + this.layout.spacingX));
                var deltaY = this.layout.paddingTop
                    + (1 - this.content.anchorY) * this.content.height
                    + (1 - this.item.anchorY) * this.item.height * this.item.scaleY
                    + Math.floor(index / cols) * (this.item.height * this.item.scaleY + this.layout.spacingY);
                var deltaX = this.layout.paddingLeft
                    + (this.item.anchorX * this.item.width * this.item.scaleX) - this.content.anchorX * this.content.width
                    + (index % cols) * (this.item.width * this.item.scaleX + this.layout.spacingX)
                return cc.v3(deltaX, -deltaY, 0);
            default:
                return cc.v3();
        }
    }
}

class ScrollViewProData {
    n: cc.Node;
    /**用户数据 */
    userData: any;
    /**节点在数据中的下标，根据index调整节点在content中的位置 */
    index: number;

    constructor(index: number, userData: any) {
        this.index = index;
        this.userData = userData;
    }
}