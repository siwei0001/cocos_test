﻿using TrueSync.Physics3D;
using UnityEngine;

namespace TrueSync
{
    /// <summary>
    /// 移动Joint
    /// </summary>
    public class TSPrismaticJoint : MonoBehaviour
    {
        public TSCollider connectedCollider;
        public TSVector ancher = TSVector.zero;
        public TSVector connectedAncher = TSVector.zero;

        public FP minimumDistance = FP.Zero;

        public FP maximumDistance = FP.Zero;

        private PrismaticJoint3D prismaticJoint3D;
        
        // Start is called before the first frame update
        void Start()
        {
            Activate();
        }

        public void Activate()
        {
            IWorld world = PhysicsManager.instance.GetWorld();
            TSCollider collider = gameObject.GetComponent<TSCollider>();
            if (world == null || collider == null || connectedCollider == null)
            {
                return;
            }

            if (prismaticJoint3D != null)
            {
                prismaticJoint3D.Activate();
                return;
            }
            
            if (minimumDistance != FP.Zero && maximumDistance != FP.Zero)
            {
                if (ancher != TSVector.zero && connectedAncher != TSVector.zero)
                {
                    prismaticJoint3D = PrismaticJoint3D.Create(world,(RigidBody)collider.Body,(RigidBody)connectedCollider.Body,ancher,connectedAncher,minimumDistance,maximumDistance);
                }
                else
                {
                    prismaticJoint3D = PrismaticJoint3D.Create(world,(RigidBody)collider.Body,(RigidBody)connectedCollider.Body,minimumDistance,maximumDistance);
                }
            }
            else
            {
                prismaticJoint3D = PrismaticJoint3D.Create(world, (RigidBody) collider.Body, (RigidBody) connectedCollider.Body);
            }
        }

        public void Deactivate()
        {
            if (prismaticJoint3D != null)
            {
                prismaticJoint3D.Deactivate();
            }
        }

        void OnDestroy()
        {
            Deactivate();
        }
    }
}