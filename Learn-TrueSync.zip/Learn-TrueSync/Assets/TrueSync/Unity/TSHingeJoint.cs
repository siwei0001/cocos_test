﻿using System;
using TrueSync.Physics3D;
using UnityEngine;

namespace TrueSync
{
    /// <summary>
    /// 铰链Joint
    /// </summary>
    public class TSHingeJoint : MonoBehaviour
    {
        public TSCollider connectedCollider;
        public TSVector ancher = TSVector.zero;
        public TSVector axis = TSVector.zero;
        private HingeJoint3D hingeJoint3D;
        void Start()
        {
            Activate();
        }

        public void Activate()
        {
            IWorld world = PhysicsManager.instance.GetWorld();
            TSCollider collider = gameObject.GetComponent<TSCollider>();
            if (world == null || collider == null || connectedCollider == null)
            {
                return;
            }

            if (hingeJoint3D != null)
            {
                hingeJoint3D.Activate();
                return;
            }

            ancher += connectedCollider.Body.TSPosition;
            hingeJoint3D = HingeJoint3D.Create(world, collider.Body, connectedCollider.Body, ancher, axis);
        }

        public void Deactivate()
        {
            if (hingeJoint3D != null)
            {
                hingeJoint3D.Deactivate();
            }
        }

        void OnDestroy()
        {
            Deactivate();
        }
    }
}