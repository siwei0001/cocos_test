﻿using System.Collections;
using System.Collections.Generic;
using TrueSync;
using UnityEngine;
using UnityEngine.UI;

namespace Table3D
{
    public class GameControl : MonoBehaviour
    {
        [SerializeField]
        private GameObject club;            //球杆

        [SerializeField]
        private GameObject whiteBulb;       //白球
        
        [SerializeField]
        private float speed;

        [SerializeField]
        private float force;

        [SerializeField]
        private Slider accumulatorSlider;     //蓄力
        
        private float minforce = 1.0f;
        private float maxforce = 100.0f;
        private float maxchargetime = 1.0f;
        private float chargespeed;

        private Vector3 clubPosition;
        
        private TSRigidBody whiteRigidBody;
        private TSVector tsPosition;
        
        void Start()
        {
            whiteRigidBody = whiteBulb.GetComponent<TSRigidBody>();
            tsPosition = whiteRigidBody.position;
            whiteRigidBody.velocity = TSVector.zero;
            
            chargespeed = (maxforce - minforce) / maxchargetime;
        }

        /// <summary>
        /// 一局是否结束
        /// </summary>
        /// <returns></returns>
        private bool RoundIsFinish()
        {
            for (int i = 0; i < GameBehaviour.BallGroup.Count; i++)
            {
                var obj = GameBehaviour.BallGroup[i] as GameObject;
                var tsRigidBody = obj.GetComponent<TSRigidBody>();
                if (!tsRigidBody.isKinematic && tsRigidBody.tsCollider._body.isActive)
                {
                    return false;
                }
            }

            return !whiteRigidBody.tsCollider._body.isActive;
        }
        
        void FixedUpdate()
        {
            if (RoundIsFinish())
            {
                if (!club.activeSelf)
                {
                    club.SetActive(true);
                    
                    club.transform.eulerAngles = new Vector3(-7.8f, 180f, -1.6f);
                    club.transform.position = whiteRigidBody.position.ToVector() + new Vector3(0,0.5f,-1);
                }
                
                MoveAndHit();
            }
            else
            {
                club.SetActive(false);
            }
        }


        private void MoveAndHit()
        {
            accumulatorSlider.value = minforce;
            
            float h = Input.GetAxis("Horizontal");
            club.transform.RotateAround(whiteBulb.transform.position, Vector3.up, h * speed);
            
            TSVector direct = whiteRigidBody.position - club.transform.position.ToTSVector();
            direct.Normalize();
            
            if(force > maxforce  )
            {
                force = maxforce;
                chargespeed = -chargespeed;
            }
            else if(force < minforce)
            {
                force = minforce;
                chargespeed = -chargespeed;
            }
            else if(Input.GetMouseButtonDown(0))
            {
                clubPosition = club.transform.position;
                force = minforce;
            }
            else if(Input.GetMouseButton(0) )
            {
                if( Mathf.Abs(club.transform.localPosition.z) < 0.4f)
                {
                    club.transform.Translate(Vector3.forward * Time.deltaTime, Space.Self);
                }
  
                force += chargespeed *Time.deltaTime;
                accumulatorSlider.value = force;
            }
            else if(Input.GetMouseButtonUp(0) )
            {
                club.transform.position = clubPosition;
                whiteRigidBody.velocity = new TSVector(direct.x, 0, direct.z) * force * 0.5f;
            }


        }
        
    }
}

