﻿using System;
using System.Collections;
using System.Collections.Generic;
using TrueSync;
using UnityEngine;

namespace Table3D
{
    public class BallBehaviour : MonoBehaviour
    {
        public int ballId = 0;
        
        //初始位置
        private TSVector tsPosition;
        private TSRigidBody tsRigidBody;
        
        private void Start()
        {
            tsRigidBody = gameObject.GetComponent<TSRigidBody>();
            tsRigidBody.tsCollider._body.isActive = false;
            tsPosition = tsRigidBody.position;
        }

        IEnumerator StopBall()
        {
            yield return null;
            tsRigidBody.isKinematic = true;
            gameObject.SetActive(false);
        }
        
        // public void OnSyncedCollisionEnter(TSCollision other) {
        // }
        public void OnSyncedTriggerEnter(TSCollision other)
        {
            if (other.gameObject.tag == "Pocket") {
                if (GameBehaviour.sixround)
                {
                    GameBehaviour.sixscore += 1;
                }
                else
                {
                    GameBehaviour.ninescore += 1;
                }
                
                GameBehaviour.goalnum += 1;
                
                if (ballId == 0)
                {
                    tsRigidBody.position = tsPosition;
                }
                else
                {
                    StartCoroutine(StopBall());
                }
                
            }
        }
        
    }
    
}

