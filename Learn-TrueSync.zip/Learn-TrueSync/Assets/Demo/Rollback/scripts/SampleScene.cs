﻿using TrueSync;
using UnityEngine;

public class SampleScene : MonoBehaviour
{
    public TrueSyncConfig config;
    public int cloneTack;
    public int restoreTack;
    public bool isFastForward;
    private GenericBufferWindow<IWorldClone> bufferWorldClone;

    internal int tick;
    
    // Start is called before the first frame update
    void Start()
    {
        PhysicsManager.New(config);
        PhysicsManager.instance.LockedTimeStep = config.lockedTimeStep;
        PhysicsManager.instance.Init();
        
        Debug.Log("rollbackwindow : " + config.rollbackWindow);
        bufferWorldClone = new GenericBufferWindow<IWorldClone>(config.rollbackWindow, new GenericBufferWindow<IWorldClone>.NewInstance(PhysicsManager.instance.GetWorldClone));

        InitGameObject();

    }

    private void InitGameObject()
    {
        var tsColliders = gameObject.GetComponentsInChildren<ICollider>();
        if (tsColliders != null)
        {
            for (int i = 0; i < tsColliders.Length; i++)
            {
                PhysicsManager.instance.AddBody(tsColliders[i]);
            }
        }
        
        TSTransform[] tsTransforms = gameObject.GetComponentsInChildren<TSTransform>();
        if (tsTransforms != null) {
            for (int index = 0, length = tsTransforms.Length; index < length; index++) {
                TSTransform tsTransform = tsTransforms[index];
                tsTransform.Initialize();
                tsTransform.position = tsTransform.gameObject.transform.position.ToTSVector();
                tsTransform.rotation = tsTransform.gameObject.transform.rotation.ToTSQuaternion();
            }
        }
    }

    private void FixedUpdate()
    {
        //追帧测试
        if (isFastForward)
        {
            for (int i = tick; i < cloneTack; i++)
            {
                OnTick();
            }
        }
        
        OnTick();
    }

    private void OnTick()
    {
        tick++;
        PhysicsManager.instance.UpdateStep();
        // Debug.Log("tick : " + tick);
        
        if (tick == restoreTack)
        {
            var chacksum = ChecksumExtractor.GetEncodedChecksum();
            Debug.Log("tick : " + tick + " hash :" + chacksum);

            tick = cloneTack;
            RestorePreviousState();
        }
        else if (tick == cloneTack)
        {
            SaveWorldClone(tick);
        }
    }

    private void RestorePreviousState()
    {
        bufferWorldClone.Current().Restore(PhysicsManager.instance.GetWorld());
    }

    private void SaveWorldClone(int refTicks)
    {
        bufferWorldClone.Current().Clone(PhysicsManager.instance.GetWorld(), refTicks % 100 == 0);
        // this.bufferWorldClone.MoveNext();
    }
    
}
