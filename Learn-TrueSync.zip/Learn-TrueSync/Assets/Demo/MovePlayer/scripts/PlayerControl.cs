﻿using UnityEngine;
using TrueSync;

/// <summary>
/// 测试父子节点，移动&旋转跟随
/// </summary>
public class PlayerControl : MonoBehaviour {

	public void Update() {
	    FP hor = (FP) Input.GetAxis("Horizontal");
		FP ver = (FP) Input.GetAxis("Vertical");
		bool space = Input.GetKey(KeyCode.Space);
		
        TSVector forceToApply = TSVector.zero;
        bool isMove = false;
        if (FP.Abs(hor) > FP.Zero) {
            forceToApply.x = hor / 3;
            isMove = true;
        }

		if (FP.Abs(ver) > FP.Zero) {
            forceToApply.z = ver / 3;
            isMove = true;
        }

		if (isMove)
		{
			var tsRigidBody = gameObject.GetComponent<TSRigidBody>();
			tsRigidBody.AddForce(forceToApply, ForceMode.Impulse);
		}
    }

    /**
    * @brief Tints box's material with gray color when it collides with the ball.
    **/
    public void OnSyncedCollisionEnter(TSCollision other) {
		if (other.gameObject.name == "Box(Clone)") {
			other.gameObject.GetComponent<Renderer> ().material.color = Color.gray;
		}
	}

    /**
    * @brief Increases box's local scale by 1% while collision with a ball remains active.
    **/
    public void OnSyncedCollisionStay(TSCollision other) {
		if (other.gameObject.name == "Box(Clone)") {
			other.gameObject.transform.localScale *= 1.01f;
		}
	}

    /**
    * @brief Resets changes in box's properties when there is no more collision with the ball.
    **/
    public void OnSyncedCollisionExit(TSCollision other) {
		if (other.gameObject.name == "Box(Clone)") {
			other.gameObject.transform.localScale = Vector3.one;
			other.gameObject.GetComponent<Renderer> ().material.color = Color.blue;
		}
	}

}