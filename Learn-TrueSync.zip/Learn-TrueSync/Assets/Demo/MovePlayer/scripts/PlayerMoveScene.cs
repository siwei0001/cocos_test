﻿using TrueSync;
using UnityEngine;

public class PlayerMoveScene : MonoBehaviour
{
    public TrueSyncConfig config;
    
    internal int tick;
    
    // Start is called before the first frame update
    void Start()
    {
        PhysicsManager.New(config);
        PhysicsManager.instance.LockedTimeStep = config.lockedTimeStep;
        PhysicsManager.instance.Init();
        
        InitGameObject();
    }

    private void InitGameObject()
    {
        var tsColliders = gameObject.GetComponentsInChildren<ICollider>();
        if (tsColliders != null)
        {
            for (int i = 0; i < tsColliders.Length; i++)
            {
                PhysicsManager.instance.AddBody(tsColliders[i]);
            }
        }
        
        TSTransform[] tsTransforms = gameObject.GetComponentsInChildren<TSTransform>();
        if (tsTransforms != null) {
            for (int index = 0, length = tsTransforms.Length; index < length; index++) {
                TSTransform tsTransform = tsTransforms[index];
                tsTransform.Initialize();
                tsTransform.position = tsTransform.gameObject.transform.position.ToTSVector();
                tsTransform.rotation = tsTransform.gameObject.transform.rotation.ToTSQuaternion();
            }
        }
    }

    private void FixedUpdate()
    {
        tick++;
        PhysicsManager.instance.UpdateStep();
    }
    
}
