using System;

public delegate void OnEventReceived(byte eventCode, object content);
