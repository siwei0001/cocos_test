using System;

namespace TrueSync
{
	[Serializable]
	public class SerializableDictionaryByteInt : SerializableDictionary<byte, int>
	{
	}
}
