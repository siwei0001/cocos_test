using System;
using System.Collections.Generic;

namespace TrueSync
{
	public delegate void TrueSyncUpdateCallback(List<InputDataBase> allInputData);
}
