using System;

namespace TrueSync
{
	public interface ResourcePoolItem
	{
		void CleanUp();
	}
}
