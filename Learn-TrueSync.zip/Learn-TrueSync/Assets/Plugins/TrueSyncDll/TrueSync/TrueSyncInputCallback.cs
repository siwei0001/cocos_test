using System;

namespace TrueSync
{
	public delegate void TrueSyncInputCallback(InputDataBase playerInputData);
}
