using System;

namespace TrueSync
{
	public delegate void ReplayRecordSave(byte[] replayRecord, int numberOfPlayers);
}
