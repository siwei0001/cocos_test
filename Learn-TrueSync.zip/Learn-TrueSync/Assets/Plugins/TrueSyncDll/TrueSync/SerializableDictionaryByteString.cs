using System;

namespace TrueSync
{
	[Serializable]
	public class SerializableDictionaryByteString : SerializableDictionary<byte, string>
	{
	}
}
