using System;

namespace TrueSync
{
	[Serializable]
	public class SerializableDictionaryByteByte : SerializableDictionary<byte, byte>
	{
	}
}
