using System;

namespace TrueSync
{
	[Serializable]
	public class SerializableDictionaryBytePlayer : SerializableDictionary<byte, TSPlayer>
	{
	}
}
