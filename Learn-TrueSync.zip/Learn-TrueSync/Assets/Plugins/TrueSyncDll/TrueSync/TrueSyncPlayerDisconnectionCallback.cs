using System;

namespace TrueSync
{
	public delegate void TrueSyncPlayerDisconnectionCallback(byte playerId);
}
