using System;

namespace TrueSync
{
    public enum ReplayMode // 重放模式
    {
        NO_REPLAY, // 不重放
        RECORD_REPLAY, // 记录重放
        LOAD_REPLAY // 载入回放
    }
}