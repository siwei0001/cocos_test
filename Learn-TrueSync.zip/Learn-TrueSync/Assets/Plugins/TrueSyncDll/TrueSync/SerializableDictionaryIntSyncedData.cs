using System;

namespace TrueSync
{
	[Serializable]
	public class SerializableDictionaryIntSyncedData : SerializableDictionary<int, SyncedData>
	{
	}
}
