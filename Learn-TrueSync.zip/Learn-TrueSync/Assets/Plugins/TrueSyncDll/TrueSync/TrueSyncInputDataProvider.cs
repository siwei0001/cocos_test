using System;

namespace TrueSync
{
	public delegate InputDataBase TrueSyncInputDataProvider();
}
