using System;

namespace TrueSync
{
	public interface ICollider
	{
	}
}
