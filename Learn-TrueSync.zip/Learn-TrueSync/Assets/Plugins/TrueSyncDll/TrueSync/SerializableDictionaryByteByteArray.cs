using System;

namespace TrueSync
{
	[Serializable]
	public class SerializableDictionaryByteByteArray : SerializableDictionary<byte, byte[]>
	{
	}
}
