using System;

namespace TrueSync
{
	public delegate void TrueSyncEventCallback();
}
