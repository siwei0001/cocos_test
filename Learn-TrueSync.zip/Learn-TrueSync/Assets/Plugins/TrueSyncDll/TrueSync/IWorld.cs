using System;
using System.Collections.Generic;

namespace TrueSync
{
	public interface IWorld
	{
		List<IBody> Bodies();
	}
}
