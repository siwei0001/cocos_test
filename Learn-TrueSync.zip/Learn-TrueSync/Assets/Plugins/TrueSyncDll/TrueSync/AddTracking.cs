using System;

namespace TrueSync
{
	[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
	public class AddTracking : Attribute
	{
	}
}
