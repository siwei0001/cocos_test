using System;

namespace TrueSync
{
	public delegate bool TrueSyncIsReady();
}
