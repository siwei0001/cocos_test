﻿using System.Collections;
using System.Collections.Generic;
using TrueSync;
using UnityEngine;

public class Remate : MonoBehaviour
{
    private TSTransform tsTransform;
    
    // Start is called before the first frame update
    void Start()
    {
        tsTransform = gameObject.GetComponent<TSTransform>();
    }

    // Update is called once per frame
    void Update()
    {
        tsTransform.Rotate(TSVector.up);
        // tsTransform.Translate(TSVector.right * 0.1);
    }
}
